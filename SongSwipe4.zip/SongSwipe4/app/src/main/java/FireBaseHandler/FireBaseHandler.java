package FireBaseHandler;
import com.example.songswipe4.Song;
import com.example.songswipe4.User;
import com.example.songswipe4.Vote;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FireBaseHandler {
    private FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
    private FirebaseFirestore firestore = FirebaseFirestore.getInstance();
    private static final String TAG = "FireBaseHandler";
    private String userId;
    public FirebaseUser getCurrentUser() {
        userId = firebaseAuth.getUid();
        return firebaseAuth.getCurrentUser();
    }
    public interface FirestoreCallback {
        void onSuccess(DocumentSnapshot document);
        void onFailure(Exception e);
    }
    public void getUserDocument(String userId, FirestoreCallback callback) {
        CollectionReference usersCollection = firestore.collection("users");
        usersCollection.document(userId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        callback.onSuccess(documentSnapshot);
                    } else {
                        callback.onFailure(new Exception("User document not found"));
                    }
                })
                .addOnFailureListener(callback::onFailure);
    }

    public void storeUserInFirestore(FirebaseUser user, String firstName, String lastName) {
        Map<String, Object> userData = new HashMap<>();
        userData.put("uid", user.getUid());
        userData.put("email", user.getEmail());
        userData.put("firstName", firstName);
        userData.put("lastName", lastName);

        firestore.collection("users").document(user.getUid())
                .set(userData, SetOptions.merge()) // Prevents overwriting existing data
                .addOnSuccessListener(aVoid -> Log.d(TAG, "User added to Firestore"))
                .addOnFailureListener(e -> Log.e(TAG, "Error adding user to Firestore", e));
    }

    public void updateSpotifyTokenInFirestore(String spotifyToken) {
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if (user != null) {
            Map<String, Object> updates = new HashMap<>();
            updates.put("spotifyToken", spotifyToken);
            firestore.collection("users").document(user.getUid())
                    .update(updates)
                    .addOnSuccessListener(aVoid -> Log.d(TAG, "Spotify token updated in Firestore."))
                    .addOnFailureListener(e -> Log.e(TAG, "Error updating Spotify token in Firestore", e));
        }
    }
    public void addToFirestore(Song song) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            Log.e("SongRecommendActivity", "User not logged in.");
            return;
        }
        String userEmail = user.getEmail();
        if (userEmail == null) {
            Log.e("SongRecommendActivity", "User email is null.");
            return;
        }

        String songId = song.getTitle() + "_" + song.getArtist() + "_" + userEmail;
        songId = songId.replaceAll("[^\\p{L}0-9-_]", "_");
        Song currSong = new Song(song.getTitle(), song.getArtist(), song.getSpotifyUri(), song.getAlbumCoverUrl(), user.getUid(), song.getPreviewUrl());

        firestore.collection("Song").document(songId).set(currSong)
                .addOnSuccessListener(aVoid -> Log.d("SongRecommendActivity", "Song added to Firestore"))
                .addOnFailureListener(e -> Log.e("SongRecommendActivity", "Error adding song to Firestore", e));
    }

    public void resetSpotifyToken(String userId, final FirestoreCallback callback) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference userDocRef = db.collection("users").document(userId);
        userDocRef.update("spotifyToken", null) // Reset the Spotify token field
                .addOnSuccessListener(aVoid -> {
                    if (callback != null) {
                        callback.onSuccess(null); // You can pass a DocumentSnapshot if needed
                    }
                })
                .addOnFailureListener(e -> {
                    if (callback != null) {
                        callback.onFailure(e);
                    }
                });
    }
    public interface GroupMembersCallback {
        void onCallback(List<String> members);
    }

    public interface VoteCallback {
        void onCallback();
    }

    public interface VotesCallback {
        void onCallback(List<Vote> votes);
    }

    // Add these new methods to your existing FireBaseHandler class
    public void getGroupMembers(String groupId, GroupMembersCallback callback) {
        firestore.collection("groups")
                .document(groupId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    List<String> members = (List<String>) documentSnapshot.get("members");
                    if (members == null) {
                        members = new ArrayList<>();
                    }
                    callback.onCallback(members);
                });
    }

    public void submitVote(String groupId, String songId, boolean liked, VoteCallback callback) {
        Map<String, Object> vote = new HashMap<>();
        vote.put("songId", songId);
        vote.put("liked", liked);
        vote.put("userId", userId);
        vote.put("timestamp", System.currentTimeMillis());

        firestore.collection("groups")
                .document(groupId)
                .collection("votes")
                .add(vote)
                .addOnSuccessListener(documentReference -> callback.onCallback());
    }

    public void getGroupVotes(String groupId, VotesCallback callback) {
        firestore.collection("groups")
                .document(groupId)
                .collection("votes")
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    List<Vote> votes = new ArrayList<>();
                    for (DocumentSnapshot doc : querySnapshot.getDocuments()) {
                        String userId = doc.getString("userId");
                        boolean liked = Boolean.TRUE.equals(doc.getBoolean("liked"));
                        votes.add(new Vote(userId, liked));
                    }
                    callback.onCallback(votes);
                });
    }
    public interface UnvotedSongCallback {
        void onCallback(DocumentSnapshot songDocument);
    }

    public void getNextUnvotedSong(String groupId, UnvotedSongCallback callback) {
        firestore.collection("groups")
                .document(groupId)
                .collection("songs")
                .whereEqualTo("voted", false)
                .limit(1)
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    if (!querySnapshot.isEmpty()) {
                        callback.onCallback(querySnapshot.getDocuments().get(0));
                    } else {
                        callback.onCallback(null);
                    }
                });
    }

    public String getId() {
        return firebaseAuth.getCurrentUser().getUid();
    }
    public void getUserLikedSongs(String userId, OnSongsLoadedListener listener) {
        firestore.collection("users")
                .document(userId)
                .collection("likedSongs")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    List<Song> songs = new ArrayList<>();
                    for (DocumentSnapshot doc : queryDocumentSnapshots) {
                        Song song = doc.toObject(Song.class);
                        songs.add(song);
                    }
                    listener.onSongsLoaded(songs);
                });
    }

    public void submitVote(String groupId, Map<String, Object> voteData, OnVoteSubmittedListener listener) {
        firestore.collection("groups")
                .document(groupId)
                .collection("votes")
                .add(voteData)
                .addOnSuccessListener(documentReference -> listener.onVoteSubmitted());
    }

    public void saveUserScore(String groupId, String userId, Map<String, Object> scoreData, OnScoreSavedListener listener) {
        firestore.collection("groups")
                .document(groupId)
                .collection("scores")
                .document(userId)
                .set(scoreData)
                .addOnSuccessListener(aVoid -> listener.onScoreSaved());
    }

    // Interface definitions
    public interface OnSongsLoadedListener {
        void onSongsLoaded(List<Song> songs);
    }

    public interface OnVoteSubmittedListener {
        void onVoteSubmitted();
    }

    public interface OnScoreSavedListener {
        void onScoreSaved();
    }
    public FirebaseFirestore getFirestore() {
        return firestore;
    }
}
