package com.example.songswipe4;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;  // Correct layout type
import androidx.core.content.ContextCompat;  // For backward compatibility
import androidx.palette.graphics.Palette;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

public class SongDetailsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_details);

        ImageView songImage = findViewById(R.id.song_image);
        TextView songName = findViewById(R.id.song_name);
        TextView songArtist = findViewById(R.id.song_artist);
        Button backButton = findViewById(R.id.back_to_playlist_button);
        ConstraintLayout layout = findViewById(R.id.song_details_layout);  // Using ConstraintLayout

        // Retrieve data passed through intent
        String imageUrl = getIntent().getStringExtra("image_url");
        String name = getIntent().getStringExtra("song_name");
        String artist = getIntent().getStringExtra("song_artist");

        // Check if the image URL is not null or empty
        if (imageUrl != null && !imageUrl.isEmpty()) {
            // Set data in views
            Picasso.get().load(imageUrl).into(songImage);
            songName.setText(name);
            songArtist.setText(artist);

            // Use Picasso Target to get the image and apply the dominant color
            Picasso.get().load(imageUrl).into(new Target() {
                @Override
                public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                    // Generate the color palette from the image
                    Palette.from(bitmap).generate(palette -> {
                        if (palette != null) {
                            // Get the dominant color and set it as the background
                            int dominantColor = palette.getDominantColor(ContextCompat.getColor(SongDetailsActivity.this, android.R.color.background_light));
                            layout.setBackgroundColor(dominantColor);

                            // Calculate the opposite color
                            int oppositeColor = getOppositeColor(dominantColor);

                            // Set the button's background to the opposite color and text to the dominant color
                            songArtist.setTextColor(oppositeColor);
                            songName.setTextColor(oppositeColor);
                            backButton.setBackgroundColor(oppositeColor);
                            backButton.setTextColor(dominantColor);

                        }
                    });
                }

                @Override
                public void onBitmapFailed(Exception e, Drawable errorDrawable) {
                    // Handle error if the image loading fails
                    layout.setBackgroundColor(ContextCompat.getColor(SongDetailsActivity.this, android.R.color.darker_gray));  // Set a default color
                }

                @Override
                public void onPrepareLoad(Drawable placeHolderDrawable) {
                    // Optional: Handle image loading preparation (e.g., loading spinner)
                }
            });
        } else {
            // Handle invalid image URL (e.g., set a default image or background)
            layout.setBackgroundColor(ContextCompat.getColor(this, android.R.color.darker_gray));
            songImage.setImageResource(R.drawable.rec);  // You can use a default image resource
        }

        // Back button logic
        backButton.setOnClickListener(v -> finish());
    }
    private int getOppositeColor(int color) {
        int r = Color.red(color);
        int g = Color.green(color);
        int b = Color.blue(color);
        r = 255 - r;
        g = 255 - g;
        b = 255 - b;
        return Color.rgb(r, g, b);
    }
}
