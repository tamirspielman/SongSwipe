package com.example.songswipe4;

import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {
    private List<String> users;
    private List<String> selectedUsers;
    private OnUserSelectedListener listener;

    public interface OnUserSelectedListener {
        void onUserSelected(List<String> selectedUsers);
    }

    public UserAdapter(List<String> users, OnUserSelectedListener listener) {
        this.users = users;
        this.listener = listener;
        this.selectedUsers = new ArrayList<>();
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        String user = users.get(position);
        holder.userNameTextView.setText(user);

        // Set the CheckBox state based on whether the user is selected
        holder.checkBox.setChecked(selectedUsers.contains(user));

        holder.itemView.setOnClickListener(v -> {
            // Toggle selection
            if (selectedUsers.contains(user)) {
                selectedUsers.remove(user);
            } else {
                selectedUsers.add(user);
            }
            // Notify the listener
            listener.onUserSelected(selectedUsers);
            // Update the CheckBox state
            holder.checkBox.setChecked(selectedUsers.contains(user));
        });
    }

    @Override
    public int getItemCount() {
        return users.size();
    }

    static class UserViewHolder extends RecyclerView.ViewHolder {
        TextView userNameTextView;
        CheckBox checkBox;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            userNameTextView = itemView.findViewById(R.id.user_name);
            checkBox = itemView.findViewById(R.id.check_box);
        }
    }
}