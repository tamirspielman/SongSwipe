package com.example.songswipe4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Group {
    private String id;
    private String name;
    private List<String> members;
    private List<String> memberIds;
    private String creatorId;
    private String creatorName;
    private Map<String, Integer> scores;
    private Map<String, Object> requests;
    private long createdAt;

    public Group() {
        // Required empty constructor for Firestore
    }

    public Group(String name, String creatorId, String creatorName) {
        this.name = name;
        this.creatorId = creatorId;
        this.creatorName = creatorName;
        this.members = new ArrayList<>();
        this.memberIds = new ArrayList<>();
        this.scores = new HashMap<>();
        this.requests = new HashMap<>();
        this.createdAt = System.currentTimeMillis();
    }

    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public List<String> getMembers() { return members; }
    public void setMembers(List<String> members) { this.members = members; }

    public List<String> getMemberIds() { return memberIds; }
    public void setMemberIds(List<String> memberIds) { this.memberIds = memberIds; }

    public String getCreatorId() { return creatorId; }
    public void setCreatorId(String creatorId) { this.creatorId = creatorId; }

    public String getCreatorName() { return creatorName; }
    public void setCreatorName(String creatorName) { this.creatorName = creatorName; }

    public Map<String, Integer> getScores() { return scores; }
    public void setScores(Map<String, Integer> scores) { this.scores = scores; }

    public Map<String, Object> getRequests() { return requests; }
    public void setRequests(Map<String, Object> requests) { this.requests = requests; }

    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }

    // Helper methods
    public boolean hasMember(String userId) {
        return memberIds != null && memberIds.contains(userId);
    }

    public boolean hasRequest(String userId) {
        return requests != null && requests.containsKey(userId);
    }

    public boolean isCreator(String userId) {
        return creatorId != null && creatorId.equals(userId);
    }

    public void addMember(String userId, String userName) {
        if (members == null) members = new ArrayList<>();
        if (memberIds == null) memberIds = new ArrayList<>();

        if (!memberIds.contains(userId)) {
            members.add(userName);
            memberIds.add(userId);
        }
    }

    public void removeMember(String userId) {
        if (memberIds != null && memberIds.contains(userId)) {
            int index = memberIds.indexOf(userId);
            if (index >= 0 && index < members.size()) {
                members.remove(index);
            }
            memberIds.remove(userId);
        }
    }
}
