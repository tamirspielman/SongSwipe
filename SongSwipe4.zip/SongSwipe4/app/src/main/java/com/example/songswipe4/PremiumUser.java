package com.example.songswipe4;
public class PremiumUser extends User {
    public PremiumUser(String uid, String email, String firstName, String lastName, String spotifyToken) {
        super(uid, email, firstName, lastName, spotifyToken);
        setPremium(true);
    }
    @Override
    public String getUserDetails(){
        return "Silver";
    }
    @Override
    public int getUserBadge(){
        return R.drawable.ic_iron_user;
    }
    @Override
    public boolean canCreateOrJoinGroup() {
        return true; // Premium users can create/join groups
    }
}