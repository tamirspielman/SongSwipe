package com.example.songswipe4;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.palette.graphics.Palette;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;

import com.google.common.reflect.TypeToken;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Type;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import FireBaseHandler.FireBaseHandler;

public class SongRecommend extends Fragment {
    private ImageView albumCover;
    private TextView songTitle, artistName;
    private View rootView;
    private List<Song> songs;
    private int currentSongIndex = 0;
    private String accessToken;
    private String userId;
    private boolean isLoading = false;
    private float x1, x2;
    private static final float MIN_DISTANCE = 150;
    private MediaPlayer mediaPlayer;

    private static List<Song> cachedSongs = new ArrayList<>();
    private static int lastPosition = 0;
    private static final int SWIPES_NEEDED_FOR_PREMIUM = 10;
    private int swipeCount = 0;
    private static boolean isFirstLoad = true;
    private SharedPreferences preferences;
    private static final String PREF_NAME = "SongSwipePrefs";
    private static final String KEY_CURRENT_INDEX = "currentIndex";
    private static final String KEY_SONGS = "cachedSongs";
    private Gson gson = new Gson();
    private static View staticRootView;
    private FireBaseHandler fireBaseHandler;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (staticRootView == null) {
            staticRootView = inflater.inflate(R.layout.fragment_song_recommend, container, false);
            rootView = staticRootView;
            initializeViews();
            loadSavedStateOrFetchNew();
            setupSwipeGesture();
        } else {
            if (staticRootView.getParent() != null) {
                ((ViewGroup) staticRootView.getParent()).removeView(staticRootView);
            }
            rootView = staticRootView;
            if (songs != null && !songs.isEmpty() && currentSongIndex < songs.size()) {
                displaySong(songs.get(currentSongIndex));
            }
        }
        return rootView;
    }

    private void initializeViews() {
        albumCover = rootView.findViewById(R.id.album_cover);
        songTitle = rootView.findViewById(R.id.song_title);
        artistName = rootView.findViewById(R.id.artist_name);
        fireBaseHandler = new FireBaseHandler();
        userId = fireBaseHandler.getCurrentUser().getUid();
        preferences = requireContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    private void loadSavedStateOrFetchNew() {
        String songsJson = preferences.getString(KEY_SONGS, null);
        if (songsJson != null) {
            Type type = new TypeToken<ArrayList<Song>>(){}.getType();
            cachedSongs = gson.fromJson(songsJson, type);
            songs = cachedSongs;
            currentSongIndex = preferences.getInt(KEY_CURRENT_INDEX, 0);
            lastPosition = currentSongIndex;
            if (songs != null && !songs.isEmpty() && currentSongIndex < songs.size()) {
                if(currentSongIndex < 100) {
                    currentSongIndex = 0;
                    reloadAfterReset();
                    fetchSongsFromSpotify();
                }
                displaySong(songs.get(currentSongIndex));
            } else {
                fetchSongsFromSpotify();
            }
        } else {
            fetchSongsFromSpotify();
        }
    }

    private void fetchSongsFromSpotify() {
        fireBaseHandler.getUserDocument(userId, new FireBaseHandler.FirestoreCallback() {
            @Override
            public void onSuccess(DocumentSnapshot document) {
                accessToken = document.getString("spotifyToken");
                if (accessToken != null) {
                    loadNewSongsFromSpotify();
                } else {
                    fetchSpotifyToken();
                }
            }

            @Override
            public void onFailure(Exception e) {
                fetchSpotifyToken();
            }
        });
    }

    private void loadNewSongsFromSpotify() {
        if (isLoading) return;
        isLoading = true;

        String playlistsUrl = "https://api.spotify.com/v1/me/playlists";
        OkHttpClient client = new OkHttpClient();
        Request playlistsRequest = new Request.Builder()
                .url(playlistsUrl)
                .addHeader("Authorization", "Bearer " + accessToken)
                .build();

        client.newCall(playlistsRequest).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                requireActivity().runOnUiThread(() -> {
                    Toast.makeText(requireContext(), "Error fetching playlists", Toast.LENGTH_SHORT).show();
                    isLoading = false;
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.code() == 200 && response.body() != null) {
                    try {
                        JSONObject jsonResponse = new JSONObject(response.body().string());
                        JSONArray playlists = jsonResponse.getJSONArray("items");
                        List<String> playlistIds = new ArrayList<>();

                        for (int i = 0; i < playlists.length(); i++) {
                            JSONObject playlist = playlists.getJSONObject(i);
                            playlistIds.add(playlist.getString("id"));
                        }

                        fetchSongsFromPlaylists(playlistIds);

                    } catch (JSONException e) {
                        handleError("Error parsing playlists");
                    }
                } else if (response.code() == 401) {
                    handleTokenExpired();
                }
            }
        });
    }

    private void fetchSongsFromPlaylists(List<String> playlistIds) {
        List<Song> allSongs = new ArrayList<>();
        final int[] completedRequests = {0};

        for (String playlistId : playlistIds) {
            String url = "https://api.spotify.com/v1/playlists/" + playlistId;
            Request request = new Request.Builder()
                    .url(url)
                    .addHeader("Authorization", "Bearer " + accessToken)
                    .build();

            new OkHttpClient().newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    synchronized (completedRequests) {
                        completedRequests[0]++;
                        checkAllRequestsComplete(completedRequests[0], playlistIds.size(), allSongs);
                    }
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.code() == 200 && response.body() != null) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response.body().string());
                            JSONArray items = jsonResponse.getJSONObject("tracks").getJSONArray("items");

                            synchronized (allSongs) {
                                for (int i = 0; i < items.length(); i++) {
                                    JSONObject trackObject = items.getJSONObject(i).getJSONObject("track");
                                    String title = trackObject.optString("name", "Unknown Title");
                                    String artist = trackObject.getJSONArray("artists").getJSONObject(0).optString("name", "Unknown Artist");
                                    String albumCoverUrl = trackObject.getJSONObject("album").getJSONArray("images").getJSONObject(0).optString("url", "");
                                    String previewUrl = trackObject.optString("preview_url", null);
                                    Song song = new Song(title, artist, trackObject.getString("uri"), albumCoverUrl, userId, previewUrl);
                                    allSongs.add(song);
                                }
                            }
                        } catch (JSONException e) {
                            Log.e("SongRecommend", "Error parsing playlist", e);
                        }
                    }

                    synchronized (completedRequests) {
                        completedRequests[0]++;
                        checkAllRequestsComplete(completedRequests[0], playlistIds.size(), allSongs);
                    }
                }
            });
        }
    }

    private void checkAllRequestsComplete(int completed, int total, List<Song> allSongs) {
        if (completed == total) {
            requireActivity().runOnUiThread(() -> {
                cachedSongs.clear();
                currentSongIndex = 0;
                cachedSongs.addAll(allSongs);
                songs = cachedSongs;

                if (isFirstLoad) {
                    SecureRandom random = new SecureRandom();
                    for (int i = cachedSongs.size() - 1; i > 0; i--) {
                        int j = random.nextInt(i + 1);
                        Collections.swap(cachedSongs, i, j);
                    }
                    isFirstLoad = false;
                }

                if (!songs.isEmpty()) {
                    displaySong(songs.get(currentSongIndex));
                }
                isLoading = false;
                saveState();
            });
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupSwipeGesture() {
        View rootLayout = rootView.findViewById(R.id.root_layout);
        rootLayout.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    x1 = event.getX();
                    return true;
                case MotionEvent.ACTION_UP:
                    x2 = event.getX();
                    float deltaX = x2 - x1;
                    if (Math.abs(deltaX) > MIN_DISTANCE) {
                        if (deltaX > 0) handleLike();
                        else handleDislike();
                    }
                    return true;
            }
            return false;
        });
    }

    private void handleLike() {
        Song likedSong = songs.get(currentSongIndex);
        fireBaseHandler.addToFirestore(likedSong);
        trackSwipe();
        animateSwipe(true);
    }

    private void handleDislike() {
        trackSwipe();
        animateSwipe(false);
    }
    private void animateSwipe(boolean isLike) {
        float direction = isLike ? 1000f : -1000f;
        ObjectAnimator animator = ObjectAnimator.ofFloat(albumCover, "translationX", 0f, direction);
        animator.setDuration(300);
        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                albumCover.setTranslationX(0f);
                nextSong();
                if (currentSongIndex + 1 < songs.size()) {
                    Picasso.get().load(songs.get(currentSongIndex).getAlbumCoverUrl()).into(albumCover);
                }
            }
        });
        animator.start();
    }

    private void displaySong(Song song) {
        if (song != null) {
            songTitle.setText(song.getTitle());
            artistName.setText(song.getArtist());
            albumCover.setTranslationX(0f);

            Picasso.get()
                    .load(song.getAlbumCoverUrl())
                    .into(albumCover);

            Picasso.get().load(song.getAlbumCoverUrl()).into(new Target() {
                @Override
                public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                    Palette.from(bitmap).generate(palette -> {
                        if (palette != null) {
                            int dominantColor = palette.getDominantColor(Color.BLACK);
                            animateBackgroundColorChange(dominantColor);
                            applyButtonColorWithAnimation(dominantColor);
                        }
                    });
                }

                @Override
                public void onBitmapFailed(Exception e, Drawable errorDrawable) {
                    Log.e("SongRecommend", "Failed to load album cover", e);
                }

                @Override
                public void onPrepareLoad(Drawable placeHolderDrawable) {
                }
            });
            playSongPreview(song.getPreviewUrl());
        }
    }

    private void animateBackgroundColorChange(int newColor) {
        int currentColor = ((ColorDrawable) rootView.getBackground()).getColor();
        ValueAnimator colorAnimation = ValueAnimator.ofObject(new ArgbEvaluator(), currentColor, newColor);
        colorAnimation.setDuration(500);
        colorAnimation.addUpdateListener(animator -> {
            int animatedValue = (int) animator.getAnimatedValue();
            rootView.setBackgroundColor(animatedValue);
        });
        colorAnimation.start();
    }

    private void applyButtonColorWithAnimation(int dominantColor) {
        int oppositeColor = getOppositeColor(dominantColor);
        TextView text1 = rootView.findViewById(R.id.artist_name);
        TextView text2 = rootView.findViewById(R.id.song_title);
        int currentTextColor1 = text1.getCurrentTextColor();
        int currentTextColor2 = text2.getCurrentTextColor();
        ValueAnimator textColorAnimation = ValueAnimator.ofObject(new ArgbEvaluator(), currentTextColor1, oppositeColor);
        textColorAnimation.setDuration(500);
        textColorAnimation.addUpdateListener(animator -> {
            int animatedValue = (int) animator.getAnimatedValue();
            text1.setTextColor(animatedValue);
            text2.setTextColor(animatedValue);
        });
        textColorAnimation.start();
    }

    private int getOppositeColor(int color) {
        int r = Color.red(color);
        int g = Color.green(color);
        int b = Color.blue(color);
        return Color.rgb(255 - r, 255 - g, 255 - b);
    }

    private void saveState() {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(KEY_CURRENT_INDEX, currentSongIndex);
        String songsJson = gson.toJson(cachedSongs);
        editor.putString(KEY_SONGS, songsJson);
        editor.apply();
    }

    private void nextSong() {
        currentSongIndex++;
        lastPosition = currentSongIndex;
        saveState();
        if (currentSongIndex < songs.size()) {
            displaySong(songs.get(currentSongIndex));
        } else {
            if (currentSongIndex == songs.size()) {
                Toast.makeText(requireContext(), "End of current song list. Loading more songs...", Toast.LENGTH_SHORT).show();
                loadNewSongsFromSpotify();
            }
        }
    }

    private void fetchSpotifyToken() {
        Intent intent = new Intent(requireContext(), LoginActivity.class);
        intent.putExtra("errAccess", true);
        startActivity(intent);
        requireActivity().finish();
    }

    public static void resetState() {
        cachedSongs.clear();
        lastPosition = 0;
        isFirstLoad = true;
    }

    public void reloadAfterReset() {
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.apply();
        isFirstLoad = true;
        currentSongIndex = 0;
        lastPosition = 0;
    }

    private void handleError(String message) {
        requireActivity().runOnUiThread(() -> {
            Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            isLoading = false;
        });
    }

    private void handleTokenExpired() {
        requireActivity().runOnUiThread(() -> {
            Toast.makeText(requireContext(), "Access token expired. Please log in again.", Toast.LENGTH_SHORT).show();
            fireBaseHandler.resetSpotifyToken(userId, new FireBaseHandler.FirestoreCallback() {
                @Override
                public void onSuccess(DocumentSnapshot document) {
                    Intent intent = new Intent(requireContext(), LoginActivity.class);
                    startActivity(intent);
                    requireActivity().finish();
                }

                @Override
                public void onFailure(Exception e) {
                    Log.e("SongRecommend", "Error resetting Spotify token", e);
                }
            });
        });
    }

    private void playSongPreview(String previewUrl) {
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
        if (previewUrl == null || previewUrl.isEmpty()) {
            Log.e("SongRecommend", "Invalid preview URL: " + previewUrl);
            Toast.makeText(requireContext(), "No preview available for this song", Toast.LENGTH_SHORT).show();
            return;
        }
        mediaPlayer = new MediaPlayer();
        try {
            Log.d("SongRecommend", "Playing preview from URL: " + previewUrl);
            mediaPlayer.setDataSource(previewUrl);
            mediaPlayer.prepare();
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(mp -> {
                if (mediaPlayer != null) {
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
            });
        } catch (IOException e) {
            if (mediaPlayer != null) {
                mediaPlayer.release();
                mediaPlayer = null;
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
    }

    private void trackSwipe() {
        swipeCount++;
        if (swipeCount >= SWIPES_NEEDED_FOR_PREMIUM) {
            checkAndUpgradeUser();
        }
    }

    private void checkAndUpgradeUser() {
        fireBaseHandler.getUserDocument(userId, new FireBaseHandler.FirestoreCallback() {
            @Override
            public void onSuccess(DocumentSnapshot document) {
                Boolean isPremium = document.getBoolean("isPremium");
                if (isPremium == null || !isPremium) {
                    fireBaseHandler.getFirestore()
                            .collection("users")
                            .document(userId)
                            .update("isPremium", true)
                            .addOnSuccessListener(aVoid -> {
                                if (isAdded()) {  // Check if Fragment is attached
                                    Toast.makeText(requireContext(),
                                            "Congratulations! You're now a Silver User!",
                                            Toast.LENGTH_LONG).show();
                                }
                            });
                }
            }

            @Override
            public void onFailure(Exception e) {
                Log.e("SongRecommend", "Error checking user status", e);
            }
        });
    }

}

