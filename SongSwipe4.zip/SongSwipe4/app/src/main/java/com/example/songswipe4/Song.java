package com.example.songswipe4;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class Song implements Parcelable {
    @SerializedName("name")
    private String title;
    @SerializedName("artists")
    private String artist;
    @SerializedName("uri")
    private String spotifyUri;
    @SerializedName("albumCoverUrl")
    private String albumCoverUrl;
    @SerializedName("userId")
    private String userId;
    @SerializedName("previewUrl")
    private String previewUrl;

    public Song() {}

    public Song(String title, String artist, String spotifyUri, String albumCoverUrl, String userId, String previewUrl) {
        this.title = title;
        this.artist = artist;
        this.spotifyUri = spotifyUri;
        this.albumCoverUrl = albumCoverUrl;
        this.userId = userId;
        this.previewUrl = previewUrl;
    }

    protected Song(Parcel in) {
        title = in.readString();
        artist = in.readString();
        spotifyUri = in.readString();
        albumCoverUrl = in.readString();
        userId = in.readString();
    }

    public static final Creator<Song> CREATOR = new Creator<Song>() {
        @Override
        public Song createFromParcel(Parcel in) {
            return new Song(in);
        }

        @Override
        public Song[] newArray(int size) {
            return new Song[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(artist);
        dest.writeString(spotifyUri);
        dest.writeString(albumCoverUrl);
        dest.writeString(userId);
    }
    public String getTitle() {
        return title;
    }
    public String getPreviewUrl() {
        return previewUrl;
    }

    public void setPreviewUrl(String previewUrl) {
        this.previewUrl = previewUrl;
    }
    public void setTitle(String title) {
        this.title = title;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getSpotifyUri() {
        return spotifyUri;
    }

    public void setSpotifyUri(String spotifyUri) {
        this.spotifyUri = spotifyUri;
    }

    public String getAlbumCoverUrl() {
        return albumCoverUrl;
    }

    public void setAlbumCoverUrl(String albumCoverUrl) {
        this.albumCoverUrl = albumCoverUrl;
    }
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}