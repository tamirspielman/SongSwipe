package com.example.songswipe4;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import android.util.Pair;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ScoreAdapter extends RecyclerView.Adapter<ScoreAdapter.ScoreViewHolder> {
    private List<Pair<String, Integer>> userScores;

    public ScoreAdapter(List<Pair<String, Integer>> userScores) {
        this.userScores = userScores;
    }

    @NonNull
    @Override
    public ScoreViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_score, parent, false);
        return new ScoreViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ScoreViewHolder holder, int position) {
        Pair<String, Integer> userScore = userScores.get(position);
        holder.bind(userScore);
    }

    @Override
    public int getItemCount() {
        return userScores.size();
    }

    public void updateScores(List<Pair<String, Integer>> newScores) {
        this.userScores = newScores;
        notifyDataSetChanged();
    }

    static class ScoreViewHolder extends RecyclerView.ViewHolder {
        private final TextView userNameTextView;
        private final TextView userScoreTextView;

        ScoreViewHolder(@NonNull View itemView) {
            super(itemView);
            userNameTextView = itemView.findViewById(R.id.user_name_text);
            userScoreTextView = itemView.findViewById(R.id.user_score_text);
        }

        void bind(Pair<String, Integer> userScore) {
            userNameTextView.setText(userScore.first);
            userScoreTextView.setText(String.format("Score: %d", userScore.second));
        }
    }
}