package com.example.songswipe4;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.util.Pair;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GroupListening extends Fragment {
    private RecyclerView groupListRecyclerView;
    private TextView fragmentTitle;
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firestore;
    private GroupAdapter groupAdapter;
    private List<Group> groups;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_group_listening, container, false);

        initializeViews(view);
        setupFirebase();
        setupRecyclerView();
        loadGroups();

        return view;
    }

    private void initializeViews(View view) {
        groupListRecyclerView = view.findViewById(R.id.group_list_recycler_view);
        fragmentTitle = view.findViewById(R.id.fragment_title);
        fragmentTitle.setText("My Groups");
    }

    private void setupFirebase() {
        firebaseAuth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
    }

    private void setupRecyclerView() {
        groups = new ArrayList<>();
        groupAdapter = new GroupAdapter(groups, this::onGroupClick);
        groupListRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        groupListRecyclerView.setAdapter(groupAdapter);
    }
    private void loadGroups() {
        String userId = firebaseAuth.getCurrentUser().getUid();

        firestore.collection("users")
                .document(userId)
                .get()
                .addOnSuccessListener(userDoc -> {
                    String userName = userDoc.getString("firstName") + " " + userDoc.getString("lastName");
                    Log.d("GroupListening", "Current user name: " + userName);

                    firestore.collection("groups")
                            .get()
                            .addOnSuccessListener(querySnapshot -> {
                                groups.clear();
                                for (DocumentSnapshot doc : querySnapshot.getDocuments()) {
                                    Map<String, Object> data = doc.getData();
                                    // Add this detailed logging
                                    Log.d("GroupListening", "Document fields: ");
                                    for (String key : data.keySet()) {
                                        Log.d("GroupListening", "Field: " + key + " = " + data.get(key));
                                    }

                                    List<String> members = (List<String>) data.get("members");
                                    if (members != null && members.contains(userName)) {
                                        Group group = doc.toObject(Group.class);
                                        group.setId(doc.getId());
                                        // The name field might be stored under a different key
                                        group.setName(doc.getString("groupName")); // Try different field name
                                        groups.add(group);
                                    }
                                }
                                groupAdapter.notifyDataSetChanged();
                            });
                });
    }
    private void onGroupClick(Group group) {
        GroupDetailsFragment detailsFragment = GroupDetailsFragment.newInstance(group.getId());
        requireActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, detailsFragment)
                .addToBackStack(null)
                .commit();
    }
}
