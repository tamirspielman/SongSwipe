package com.example.songswipe4;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.palette.graphics.Palette;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class SongVotingActivity extends AppCompatActivity {
    private static final String TAG = "SongVotingActivity";
    private static final float MIN_DISTANCE = 150;

    // Score ranges
    private static final int MIN_LIKE_SCORE = 10;
    private static final int MAX_LIKE_SCORE = 20;
    private static final int MIN_DISLIKE_SCORE = 5;
    private static final int MAX_DISLIKE_SCORE = 10;
    private static final int MIN_SONG_LIKED_SCORE = 7;
    private static final int MAX_SONG_LIKED_SCORE = 14;

    private String groupId;
    private String currentUserId;
    private float x1, x2;
    private ImageView albumCover;
    private TextView songTitle, artistName, addedByText;
    private ConstraintLayout rootLayout;
    private ValueAnimator colorAnimation;
    private MediaPlayer mediaPlayer;
    private FirebaseFirestore firestore;
    private FirebaseAuth firebaseAuth;
    private List<Song> groupSongs;
    private int currentSongIndex;
    private int userScore;
    private int previousUserScore = 0; // To store the user's previous score
    private boolean isLoading = false;
    private Button returnButton;
    private Random random = new Random(); // For generating random scores within ranges

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_voting);

        initializeVariables();
        setupViews();
        setupSwipeGesture();
        setupReturnButton();

        // Display initial loading message
        songTitle.setText("Loading songs...");
        artistName.setText("Please wait");
        addedByText.setText("");

        // Set a default image while loading
        albumCover.setImageResource(R.drawable.default_album_cover);

        // Load the user's previous score first, then load songs
        loadPreviousScore();
    }

    private void initializeVariables() {
        firestore = FirebaseFirestore.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();
        groupId = getIntent().getStringExtra("GROUP_ID");
        currentUserId = firebaseAuth.getCurrentUser().getUid();
        groupSongs = new ArrayList<>();
        currentSongIndex = 0;
        userScore = 0;

        if (groupId == null) {
            Log.e(TAG, "No group ID provided");
            Toast.makeText(this, "Error: Group not found", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void setupViews() {
        albumCover = findViewById(R.id.song_image);
        songTitle = findViewById(R.id.songTitleText);
        artistName = findViewById(R.id.artistText);
        addedByText = findViewById(R.id.added_by_text);
        rootLayout = findViewById(R.id.song_voting_layout);
        returnButton = findViewById(R.id.return_button);
    }

    private void setupReturnButton() {
        returnButton = findViewById(R.id.return_button);
        if (returnButton == null) {
            // If the button doesn't exist in the layout, create it programmatically
            returnButton = new Button(this);
            returnButton.setId(View.generateViewId());
            returnButton.setText("Return to Group");

            ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(
                    ConstraintLayout.LayoutParams.WRAP_CONTENT,
                    ConstraintLayout.LayoutParams.WRAP_CONTENT
            );
            params.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID;
            params.startToStart = ConstraintLayout.LayoutParams.PARENT_ID;
            params.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID;
            params.bottomMargin = 32;

            returnButton.setLayoutParams(params);
            rootLayout.addView(returnButton);
        }

        returnButton.setOnClickListener(v -> {
            // Save current progress before returning
            if (currentSongIndex > 0) {
                saveCurrentProgress();
            }
            finish();
        });
    }

    private void loadPreviousScore() {
        // First check the scores collection
        firestore.collection("groups").document(groupId)
                .collection("scores")
                .document(currentUserId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists() && documentSnapshot.contains("score")) {
                        previousUserScore = documentSnapshot.getLong("score").intValue();
                        Log.d(TAG, "Loaded previous score from scores collection: " + previousUserScore);
                    } else {
                        // If not found in scores collection, check the group document
                        firestore.collection("groups").document(groupId)
                                .get()
                                .addOnSuccessListener(groupDoc -> {
                                    if (groupDoc.exists()) {
                                        Map<String, Object> scores = (Map<String, Object>) groupDoc.get("scores");
                                        if (scores != null && scores.containsKey(currentUserId)) {
                                            Object scoreObj = scores.get(currentUserId);
                                            if (scoreObj instanceof Number) {
                                                previousUserScore = ((Number) scoreObj).intValue();
                                                Log.d(TAG, "Loaded previous score from group document: " + previousUserScore);
                                            }
                                        }
                                    }
                                    // Initialize user score with previous score
                                    userScore = previousUserScore;
                                    // Now load the songs
                                    loadGroupSongs();
                                })
                                .addOnFailureListener(e -> {
                                    Log.e(TAG, "Error loading previous score from group document", e);
                                    // Initialize with 0 and continue
                                    userScore = 0;
                                    loadGroupSongs();
                                });
                    }
                    // Initialize user score with previous score
                    userScore = previousUserScore;
                    // Now load the songs
                    loadGroupSongs();
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error loading previous score", e);
                    // Initialize with 0 and continue
                    userScore = 0;
                    loadGroupSongs();
                });
    }

    private void saveCurrentProgress() {
        // Save the current score even if user hasn't finished all songs
        Map<String, Object> scoreData = new HashMap<>();
        scoreData.put("score", userScore);
        scoreData.put("timestamp", System.currentTimeMillis());

        firestore.collection("groups").document(groupId)
                .collection("scores")
                .document(currentUserId)
                .set(scoreData)
                .addOnSuccessListener(aVoid -> {
                    // Also update the user's score in the group document
                    updateGroupScores(userScore);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error saving partial score", e);
                });
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupSwipeGesture() {
        rootLayout.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    x1 = event.getX();
                    return true;
                case MotionEvent.ACTION_UP:
                    x2 = event.getX();
                    float deltaX = x2 - x1;
                    if (Math.abs(deltaX) > MIN_DISTANCE) {
                        if (!isLoading) {
                            animateSwipe(deltaX > 0);
                        } else {
                            Toast.makeText(this, "Still loading songs, please wait...", Toast.LENGTH_SHORT).show();
                        }
                    }
                    return true;
            }
            return false;
        });
    }

    private void loadGroupSongs() {
        Log.d(TAG, "Loading songs for group: " + groupId);
        isLoading = true;

        // First, get all members of the group
        firestore.collection("groups").document(groupId)
                .get()
                .addOnSuccessListener(document -> {
                    if (document.exists()) {
                        // Get memberIds from the group document
                        List<String> memberIds = (List<String>) document.get("memberIds");

                        if (memberIds == null || memberIds.isEmpty()) {
                            // Fall back to members list if memberIds is not available
                            Log.d(TAG, "No memberIds found, checking members list");
                            memberIds = (List<String>) document.get("members");
                        }

                        if (memberIds != null && !memberIds.isEmpty()) {
                            Log.d(TAG, "Group has " + memberIds.size() + " members");
                            songTitle.setText("Found " + memberIds.size() + " members");

                            // Create a list to store other members (excluding current user)
                            List<String> otherMembers = new ArrayList<>();
                            for (String memberId : memberIds) {
                                if (!memberId.equals(currentUserId)) {
                                    otherMembers.add(memberId);
                                }
                            }

                            if (otherMembers.isEmpty()) {
                                Log.w(TAG, "No other members in the group to load songs from");
                                Toast.makeText(this, "No other members in the group to vote on songs", Toast.LENGTH_LONG).show();
                                finish();
                                return;
                            }

                            songTitle.setText("Loading songs from " + otherMembers.size() + " members");

                            // Load songs from each member
                            loadSongsFromMembers(otherMembers);
                        } else {
                            Log.e(TAG, "No members found in group");
                            Toast.makeText(this, "No members found in group", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    } else {
                        Log.e(TAG, "Group document does not exist");
                        Toast.makeText(this, "Group not found", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error loading group", e);
                    Toast.makeText(this, "Error loading group: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    finish();
                });
    }

    private void loadSongsFromMembers(List<String> members) {
        // Counter to track when all queries are complete
        final int[] completedQueries = {0};
        final int totalQueries = members.size();

        for (String userId : members) {
            // Using the same approach as in Playlist fragment
            firestore.collection("Song")
                    .whereEqualTo("userId", userId)
                    .get()
                    .addOnSuccessListener(querySnapshot -> {
                        Log.d(TAG, "Found " + querySnapshot.size() + " songs for user " + userId);

                        for (QueryDocumentSnapshot doc : querySnapshot) {
                            try {
                                String title = doc.getString("title");
                                String artist = doc.getString("artist");
                                String albumCoverUrl = doc.getString("albumCoverUrl");
                                String previewUrl = doc.getString("previewUrl");
                                String spotifyUri = doc.getString("spotifyUri");

                                if (title != null && artist != null) {
                                    Song song = new Song();
                                    song.setTitle(title);
                                    song.setArtist(artist);
                                    song.setAlbumCoverUrl(albumCoverUrl);
                                    song.setPreviewUrl(previewUrl);
                                    song.setSpotifyUri(spotifyUri != null ? spotifyUri : doc.getId());
                                    song.setUserId(userId);

                                    // Check for duplicates
                                    boolean isDuplicate = false;
                                    for (Song existingSong : groupSongs) {
                                        if (existingSong.getTitle().equals(title) &&
                                                existingSong.getArtist().equals(artist)) {
                                            isDuplicate = true;
                                            break;
                                        }
                                    }

                                    if (!isDuplicate) {
                                        groupSongs.add(song);
                                        Log.d(TAG, "Added song: " + title + " by " + artist);
                                    }
                                }
                            } catch (Exception e) {
                                Log.e(TAG, "Error processing song document", e);
                            }
                        }

                        // Check if all queries are complete
                        completedQueries[0]++;
                        checkAllQueriesComplete(completedQueries[0], totalQueries);
                    })
                    .addOnFailureListener(e -> {
                        Log.e(TAG, "Error loading songs for user " + userId, e);

                        // Even on failure, increment the counter
                        completedQueries[0]++;
                        checkAllQueriesComplete(completedQueries[0], totalQueries);
                    });
        }
    }

    private void checkAllQueriesComplete(int completed, int total) {
        if (completed == total) {
            Log.d(TAG, "All queries completed. Found " + groupSongs.size() + " songs");

            if (groupSongs.isEmpty()) {
                Toast.makeText(this, "No songs found to vote on", Toast.LENGTH_LONG).show();
                finish();
                return;
            }

            // Shuffle the songs for variety
            java.util.Collections.shuffle(groupSongs);

            // Start displaying songs
            isLoading = false;
            displayCurrentSong();
        }
    }
    private void displayCurrentSong() {
        if (currentSongIndex < groupSongs.size()) {
            Song currentSong = groupSongs.get(currentSongIndex);
            Log.d(TAG, "Displaying song " + (currentSongIndex + 1) + "/" + groupSongs.size() +
                    ": " + currentSong.getTitle() + " by " + currentSong.getArtist());

            songTitle.setText(currentSong.getTitle());
            artistName.setText(currentSong.getArtist());
            albumCover.setTranslationX(0f);

            // Load user info for "Added by" text
            loadUserInfo(currentSong.getUserId());

            // Load album cover and apply color palette
            if (currentSong.getAlbumCoverUrl() != null && !currentSong.getAlbumCoverUrl().isEmpty()) {
                Picasso.get().load(currentSong.getAlbumCoverUrl()).into(albumCover);

                Picasso.get().load(currentSong.getAlbumCoverUrl()).into(new Target() {
                    @Override
                    public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                        Palette.from(bitmap).generate(palette -> {
                            if (palette != null) {
                                int dominantColor = palette.getDominantColor(Color.BLACK);
                                animateBackgroundColorChange(dominantColor);
                                updateTextColors(dominantColor);
                            }
                        });
                    }

                    @Override
                    public void onBitmapFailed(Exception e, Drawable errorDrawable) {
                        Log.e(TAG, "Failed to load album cover", e);
                    }

                    @Override
                    public void onPrepareLoad(Drawable placeHolderDrawable) {}
                });
            } else {
                albumCover.setImageResource(R.drawable.default_album_cover);
            }

            // Play song preview
            playSongPreview(currentSong.getPreviewUrl());
        } else {
            finishVoting();
        }
    }

    private void loadUserInfo(String userId) {
        firestore.collection("users").document(userId)
                .get()
                .addOnSuccessListener(document -> {
                    if (document.exists()) {
                        String firstName = document.getString("firstName");
                        String lastName = document.getString("lastName");

                        if (firstName != null && lastName != null) {
                            addedByText.setText("Added by: " + firstName + " " + lastName);
                        } else {
                            String username = document.getString("username");
                            addedByText.setText("Added by: " + (username != null ? username : "Unknown User"));
                        }
                    } else {
                        addedByText.setText("Added by: Unknown User");
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error loading user details", e);
                    addedByText.setText("Added by: Unknown User");
                });
    }

    private void animateSwipe(boolean isLike) {
        float direction = isLike ? 1000f : -1000f;
        ObjectAnimator animator = ObjectAnimator.ofFloat(albumCover, "translationX", 0f, direction);
        animator.setDuration(300);
        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                submitVote(isLike);
            }
        });
        animator.start();
    }

    private void submitVote(boolean liked) {
        Song currentSong = groupSongs.get(currentSongIndex);
        Log.d(TAG, "Submitting vote for song: " + currentSong.getTitle() + ", liked: " + liked);

        // Check if user is TopUser
        firestore.collection("users").document(currentUserId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    String userType = documentSnapshot.getString("userType");
                    boolean isTopUser = "TOP".equals(userType);

                    // Calculate score based on the new scoring system
                    int voteScore;
                    if (liked) {
                        // Random score between MIN_LIKE_SCORE and MAX_LIKE_SCORE
                        voteScore = random.nextInt(MAX_LIKE_SCORE - MIN_LIKE_SCORE + 1) + MIN_LIKE_SCORE;
                    } else {
                        // Random score between MIN_DISLIKE_SCORE and MAX_DISLIKE_SCORE
                        voteScore = random.nextInt(MAX_DISLIKE_SCORE - MIN_DISLIKE_SCORE + 1) + MIN_DISLIKE_SCORE;
                    }

                    // Double points for TopUser
                    if (isTopUser) {
                        voteScore *= 2;
                    }

                    Map<String, Object> vote = new HashMap<>();
                    vote.put("songId", currentSong.getSpotifyUri());
                    vote.put("userId", currentUserId);
                    vote.put("liked", liked);
                    vote.put("timestamp", System.currentTimeMillis());
                    vote.put("score", voteScore);

                    // If the song is liked, also give points to the song owner
                    if (liked) {
                        // Random score between MIN_SONG_LIKED_SCORE and MAX_SONG_LIKED_SCORE
                        int songOwnerScore = random.nextInt(MAX_SONG_LIKED_SCORE - MIN_SONG_LIKED_SCORE + 1) + MIN_SONG_LIKED_SCORE;
                        vote.put("songOwnerScore", songOwnerScore);

                        // Update the song owner's score
                        updateSongOwnerScore(currentSong.getUserId(), songOwnerScore);
                    }

                    int finalVoteScore = voteScore;
                    firestore.collection("groups").document(groupId)
                            .collection("votes")
                            .add(vote)
                            .addOnSuccessListener(documentReference -> {
                                // Add to user score
                                userScore += finalVoteScore;
                                currentSongIndex++;
                                albumCover.setTranslationX(0f);

                                if (currentSongIndex < groupSongs.size()) {
                                    displayCurrentSong();
                                } else {
                                    finishVoting();
                                }
                            })
                            .addOnFailureListener(e -> {
                                Log.e(TAG, "Error submitting vote", e);
                                Toast.makeText(SongVotingActivity.this,
                                        "Failed to submit vote: " + e.getMessage(),
                                        Toast.LENGTH_SHORT).show();
                                // Still move to next song
                                userScore += finalVoteScore;
                                currentSongIndex++;
                                albumCover.setTranslationX(0f);

                                if (currentSongIndex < groupSongs.size()) {
                                    displayCurrentSong();
                                } else {
                                    finishVoting();
                                }
                            });
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error checking if user is TopUser", e);
                    // Use default score
                    int voteScore;
                    if (liked) {
                        voteScore = random.nextInt(MAX_LIKE_SCORE - MIN_LIKE_SCORE + 1) + MIN_LIKE_SCORE;
                    } else {
                        voteScore = random.nextInt(MAX_DISLIKE_SCORE - MIN_DISLIKE_SCORE + 1) + MIN_DISLIKE_SCORE;
                    }

                    userScore += voteScore;
                    currentSongIndex++;
                    albumCover.setTranslationX(0f);

                    if (currentSongIndex < groupSongs.size()) {
                        displayCurrentSong();
                    } else {
                        finishVoting();
                    }
                });
    }

    private void updateSongOwnerScore(String songOwnerId, int scoreToAdd) {
        if (songOwnerId.equals(currentUserId)) {
            // Skip if the song owner is the current user (already getting points for liking)
            return;
        }

        // First check the scores collection
        firestore.collection("groups").document(groupId)
                .collection("scores")
                .document(songOwnerId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    int currentScore = 0;
                    if (documentSnapshot.exists() && documentSnapshot.contains("score")) {
                        currentScore = documentSnapshot.getLong("score").intValue();
                    }

                    // Add the new score
                    int newScore = currentScore + scoreToAdd;

                    // Update the score in the scores collection
                    Map<String, Object> scoreData = new HashMap<>();
                    scoreData.put("score", newScore);
                    scoreData.put("timestamp", System.currentTimeMillis());

                    firestore.collection("groups").document(groupId)
                            .collection("scores")
                            .document(songOwnerId)
                            .set(scoreData)
                            .addOnSuccessListener(aVoid -> {
                                // Also update the score in the group document
                                updateGroupScoreForUser(songOwnerId, newScore);
                            })
                            .addOnFailureListener(e -> {
                                Log.e(TAG, "Error updating song owner score in scores collection", e);
                            });
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting song owner's current score", e);

                    // Fallback: try to get the score from the group document
                    firestore.collection("groups").document(groupId)
                            .get()
                            .addOnSuccessListener(groupDoc -> {
                                if (groupDoc.exists()) {
                                    Map<String, Object> scores = (Map<String, Object>) groupDoc.get("scores");
                                    int currentScore = 0;
                                    if (scores != null && scores.containsKey(songOwnerId)) {
                                        Object scoreObj = scores.get(songOwnerId);
                                        if (scoreObj instanceof Number) {
                                            currentScore = ((Number) scoreObj).intValue();
                                        }
                                    }

                                    // Add the new score
                                    int newScore = currentScore + scoreToAdd;

                                    // Update directly in the group document
                                    updateGroupScoreForUser(songOwnerId, newScore);
                                }
                            })
                            .addOnFailureListener(e2 -> {
                                Log.e(TAG, "Error getting group document for song owner score update", e2);
                            });
                });
    }

    private void updateGroupScoreForUser(String userId, int newScore) {
        firestore.collection("groups").document(groupId)
                .get()
                .addOnSuccessListener(document -> {
                    if (document.exists()) {
                        // Get the scores map or create a new one if it doesn't exist
                        Map<String, Object> groupData = document.getData();
                        Map<String, Object> scores;

                        if (groupData.containsKey("scores")) {
                            scores = (Map<String, Object>) groupData.get("scores");
                        } else {
                            scores = new HashMap<>();
                        }

                        if (scores == null) {
                            scores = new HashMap<>();
                        }

                        // Update the user's score
                        scores.put(userId, newScore);

                        // Update the group document
                        firestore.collection("groups").document(groupId)
                                .update("scores", scores)
                                .addOnSuccessListener(aVoid -> {
                                    Log.d(TAG, "Successfully updated score for user " + userId);
                                })
                                .addOnFailureListener(e -> {
                                    Log.e(TAG, "Error updating score for user " + userId, e);
                                });
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting group document for score update", e);
                });
    }

    private void finishVoting() {
        Log.d(TAG, "Finishing voting with score: " + userScore);

        Map<String, Object> scoreData = new HashMap<>();
        scoreData.put("score", userScore);
        scoreData.put("timestamp", System.currentTimeMillis());

        firestore.collection("groups").document(groupId)
                .collection("scores")
                .document(currentUserId)
                .set(scoreData)
                .addOnSuccessListener(aVoid -> {
                    // Also update the user's score in the group document
                    updateGroupScores(userScore);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error saving final score", e);
                    Toast.makeText(SongVotingActivity.this,
                            "Failed to save score: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                    finish();
                });
    }

    private void updateGroupScores(int newScore) {
        // Get the current group document
        firestore.collection("groups").document(groupId)
                .get()
                .addOnSuccessListener(document -> {
                    if (document.exists()) {
                        // Get the scores map or create a new one if it doesn't exist
                        Map<String, Object> groupData = document.getData();
                        Map<String, Object> scores;

                        if (groupData.containsKey("scores")) {
                            scores = (Map<String, Object>) groupData.get("scores");
                        } else {
                            scores = new HashMap<>();
                        }

                        if (scores == null) {
                            scores = new HashMap<>();
                        }

                        // Update the user's score
                        scores.put(currentUserId, newScore);

                        // Update the group document
                        firestore.collection("groups").document(groupId)
                                .update("scores", scores)
                                .addOnSuccessListener(aVoid -> {
                                    Log.d(TAG, "Successfully updated group scores");
                                    Intent resultIntent = new Intent();
                                    resultIntent.putExtra("FINAL_SCORE", userScore);
                                    setResult(RESULT_OK, resultIntent);
                                    finish();
                                })
                                .addOnFailureListener(e -> {
                                    Log.e(TAG, "Error updating group scores", e);
                                    // Still finish the activity even if this update fails
                                    Intent resultIntent = new Intent();
                                    resultIntent.putExtra("FINAL_SCORE", userScore);
                                    setResult(RESULT_OK, resultIntent);
                                    finish();
                                });
                    } else {
                        Log.e(TAG, "Group document does not exist");
                        Intent resultIntent = new Intent();
                        resultIntent.putExtra("FINAL_SCORE", userScore);
                        setResult(RESULT_OK, resultIntent);
                        finish();
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error getting group document", e);
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("FINAL_SCORE", userScore);
                    setResult(RESULT_OK, resultIntent);
                    finish();
                });
    }
    private void animateBackgroundColorChange(int newColor) {
        int currentColor;
        Drawable background = rootLayout.getBackground();
        if (background instanceof ColorDrawable) {
            currentColor = ((ColorDrawable) background).getColor();
        } else {
            currentColor = Color.BLACK;
        }

        if (colorAnimation != null) {
            colorAnimation.cancel();
        }

        colorAnimation = ValueAnimator.ofObject(new ArgbEvaluator(), currentColor, newColor);
        colorAnimation.setDuration(500);
        colorAnimation.addUpdateListener(animator -> {
            int animatedValue = (int) animator.getAnimatedValue();
            rootLayout.setBackgroundColor(animatedValue);
        });
        colorAnimation.start();
    }
    private void updateTextColors(int backgroundColor) {
        int textColor = getContrastColor(backgroundColor);
        songTitle.setTextColor(textColor);
        artistName.setTextColor(textColor);
        addedByText.setTextColor(textColor);
        returnButton.setTextColor(textColor);
    }

    private int getContrastColor(int color) {
        double y = (299 * Color.red(color) + 587 * Color.green(color) + 114 * Color.blue(color)) / 1000;
        return y >= 128 ? Color.BLACK : Color.WHITE;
    }

    private void playSongPreview(String previewUrl) {
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }

        if (previewUrl == null || previewUrl.isEmpty()) {
            Log.w(TAG, "No preview URL available for song");
            return;
        }

        mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(previewUrl);
            mediaPlayer.prepare();
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(mp -> {
                if (mediaPlayer != null) {
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
            });
        } catch (IOException e) {
            Log.e(TAG, "Error playing preview: " + previewUrl, e);
            if (mediaPlayer != null) {
                mediaPlayer.release();
                mediaPlayer = null;
            }
        } catch (IllegalStateException | IllegalArgumentException e) {
            Log.e(TAG, "Error with MediaPlayer", e);
            if (mediaPlayer != null) {
                mediaPlayer.release();
                mediaPlayer = null;
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (colorAnimation != null) {
            colorAnimation.cancel();
        }
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}