package com.example.songswipe4;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

public class GroupDetailsFragment extends Fragment {
    private static final String ARG_GROUP_ID = "group_id";
    private static final String TAG = "GroupDetailsFragment";
    private static final int SONG_VOTING_REQUEST_CODE = 1001;

    private String groupId;
    private MembersAdapter membersAdapter;
    private List<MembersAdapter.MemberData> membersList = new ArrayList<>();

    private TextView groupNameText;
    private RecyclerView membersRecyclerView;
    private Button voteSongsButton;
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firestore;

    // Flag to prevent multiple simultaneous loads
    private boolean isLoading = false;

    public static GroupDetailsFragment newInstance(String groupId) {
        GroupDetailsFragment fragment = new GroupDetailsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_GROUP_ID, groupId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            groupId = getArguments().getString(ARG_GROUP_ID);
        }
        firebaseAuth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_group_details, container, false);
        initializeViews(view);
        setupVoteSongsButton();
        loadGroupDetails();
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Only reload if we're not already loading
        if (!isLoading) {
            loadGroupDetails();
        }
    }

    private void initializeViews(View view) {
        groupNameText = view.findViewById(R.id.group_name_text);
        membersRecyclerView = view.findViewById(R.id.members_recycler_view);
        voteSongsButton = view.findViewById(R.id.vote_songs_button);

        membersList = new ArrayList<>();
        membersAdapter = new MembersAdapter(membersList);
        membersRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        membersRecyclerView.setAdapter(membersAdapter);
    }

    private void setupVoteSongsButton() {
        voteSongsButton.setOnClickListener(v -> startVoting());
    }

    private void loadGroupDetails() {
        // Set loading flag to prevent multiple simultaneous loads
        if (isLoading) return;
        isLoading = true;

        // Clear the members list
        membersList.clear();
        membersAdapter.notifyDataSetChanged();

        firestore.collection("groups").document(groupId)
                .get()
                .addOnSuccessListener(document -> {
                    if (document.exists()) {
                        String groupName = document.getString("groupName");
                        groupNameText.setText(groupName);

                        // Get the members list - prioritize memberIds over members
                        List<String> memberIds = (List<String>) document.get("memberIds");
                        if (memberIds == null || memberIds.isEmpty()) {
                            // Fall back to members list if memberIds is not available
                            memberIds = (List<String>) document.get("members");
                        }

                        // Get scores directly from the group document
                        Map<String, Object> scoresMap = (Map<String, Object>) document.get("scores");
                        if (scoresMap == null) {
                            scoresMap = new HashMap<>();
                        }

                        // Load scores and member details
                        if (memberIds != null && !memberIds.isEmpty()) {
                            // Remove duplicates from memberIds
                            Set<String> uniqueMemberIds = new HashSet<>(memberIds);
                            List<String> uniqueMembers = new ArrayList<>(uniqueMemberIds);

                            fetchAllMemberData(uniqueMembers, scoresMap);
                        } else {
                            Log.w(TAG, "No members found in group");
                            isLoading = false;
                        }
                    } else {
                        isLoading = false;
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error loading group details", e);
                    Toast.makeText(getContext(), "Error loading group details: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    isLoading = false;
                });
    }

    private void fetchAllMemberData(List<String> memberIds, Map<String, Object> groupScores) {
        Map<String, MembersAdapter.MemberData> memberDataMap = new HashMap<>();

        // First, create basic member entries with scores from the group document
        for (String userId : memberIds) {
            int score = 0;
            if (groupScores.containsKey(userId) && groupScores.get(userId) instanceof Number) {
                score = ((Number) groupScores.get(userId)).intValue();
            }

            // Defaulting userType to "Regular" without using Settings
            memberDataMap.put(userId, new MembersAdapter.MemberData(
                    "Loading...", score, "Regular", userId));
        }
        // Now fetch additional scores from the scores collection
        firestore.collection("groups").document(groupId)
                .collection("scores")
                .get()
                .addOnSuccessListener(scoresSnapshot -> {
                    for (DocumentSnapshot scoreDoc : scoresSnapshot.getDocuments()) {
                        String userId = scoreDoc.getId();
                        Number scoreValue = scoreDoc.getLong("score");

                        if (scoreValue != null && memberDataMap.containsKey(userId)) {
                            // Update the score in our map
                            MembersAdapter.MemberData existingData = memberDataMap.get(userId);
                            memberDataMap.put(userId, new MembersAdapter.MemberData(
                                    existingData.name, scoreValue.intValue(),
                                    existingData.userType, existingData.userId));
                        }
                    }

                    // Now fetch user details for each member
                    fetchUserDetails(memberDataMap);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error loading scores collection", e);
                    // Continue with user details even if scores fail
                    fetchUserDetails(memberDataMap);
                });
    }

    private void fetchUserDetails(Map<String, MembersAdapter.MemberData> memberDataMap) {
        AtomicInteger pendingRequests = new AtomicInteger(memberDataMap.size());

        if (memberDataMap.isEmpty()) {
            isLoading = false;
            return;
        }

        for (String userId : memberDataMap.keySet()) {
            firestore.collection("users").document(userId)
                    .get()
                    .addOnSuccessListener(userDoc -> {
                        if (userDoc.exists()) {
                            String firstName = userDoc.getString("firstName");
                            String lastName = userDoc.getString("lastName");
                            String fullName = (firstName != null && lastName != null) ?
                                    firstName + " " + lastName : userDoc.getString("username");

                            if (fullName == null) {
                                fullName = "Unknown User";
                            }

                            // Get user status flags
                            boolean isPremium = userDoc.getBoolean("isPremium") != null &&
                                    userDoc.getBoolean("isPremium");
                            boolean isTopUser = userDoc.getBoolean("isTopUser") != null &&
                                    userDoc.getBoolean("isTopUser");

                            // Create the appropriate user object based on status
                            User user;
                            if (isTopUser) {
                                user = new TopUser(userId, userDoc.getString("email"), firstName, lastName, null);
                            } else if (isPremium) {
                                user = new PremiumUser(userId, userDoc.getString("email"), firstName, lastName, null);
                            } else {
                                user = new User(userId, userDoc.getString("email"), firstName, lastName, null);
                            }

                            // Use the polymorphic method to get user details
                            String userType = user.getUserDetails();

                            MembersAdapter.MemberData currentData = memberDataMap.get(userId);
                            memberDataMap.put(userId, new MembersAdapter.MemberData(
                                    fullName, currentData.score, userType, userId));
                        }

                        if (pendingRequests.decrementAndGet() == 0) {
                            finalizeMembers(memberDataMap);
                        }
                    })
                    .addOnFailureListener(e -> {
                        Log.e(TAG, "Error fetching user details for " + userId, e);
                        if (pendingRequests.decrementAndGet() == 0) {
                            finalizeMembers(memberDataMap);
                        }
                    });
        }
    }


    private void finalizeMembers(Map<String, MembersAdapter.MemberData> memberDataMap) {
        // Clear the list again to be safe
        membersList.clear();

        // Add all members from the map to the list
        membersList.addAll(memberDataMap.values());

        // Sort by score
        membersList.sort((m1, m2) -> Integer.compare(m2.score, m1.score));

        // Update top user status if there are members
        if (!membersList.isEmpty()) {
            updateTopUserStatus(membersList.get(0).userId);
        }

        // Update the adapter
        membersAdapter.notifyDataSetChanged();

        // Reset loading flag
        isLoading = false;

        // Log the final list for debugging
        Log.d(TAG, "Final members list size: " + membersList.size());
        for (MembersAdapter.MemberData member : membersList) {
            Log.d(TAG, "Member: " + member.name + ", ID: " + member.userId + ", Score: " + member.score);
        }
    }

    private void updateTopUserStatus(String topUserId) {
        String currentUserId = firebaseAuth.getCurrentUser().getUid();
        boolean isCurrentUserTopUser = topUserId.equals(currentUserId);

        // Update the current user's status
        firestore.collection("users").document(currentUserId)
                .get()
                .addOnSuccessListener(userDoc -> {
                    if (userDoc.exists()) {
                        Boolean wasAlreadyTopUser = userDoc.getBoolean("isTopUser");

                        // If user was already a top user, they stay a top user
                        if (wasAlreadyTopUser != null && wasAlreadyTopUser) {
                            // No need to update anything, they're already a top user
                            return;
                        }

                        // Only show toast if user wasn't already a top user but is now
                        boolean showTopUserToast = isCurrentUserTopUser && (wasAlreadyTopUser == null || !wasAlreadyTopUser);

                        // Only update if the user is becoming a top user
                        if (isCurrentUserTopUser) {
                            Map<String, Object> updates = new HashMap<>();
                            updates.put("isTopUser", true);
                            updates.put("userType", "Top");

                            firestore.collection("users")
                                    .document(currentUserId)
                                    .update(updates)
                                    .addOnSuccessListener(aVoid -> {
                                        if (showTopUserToast) {
                                            Toast.makeText(getContext(), "Congratulations! You're now a Top User!",
                                                    Toast.LENGTH_LONG).show();
                                        }
                                    });
                        }

                    }
                });
    }

    private void startVoting() {
        Log.d("GroupDetails", "Starting voting with groupId: " + groupId);
        Intent intent = new Intent(getActivity(), SongVotingActivity.class);
        intent.putExtra("GROUP_ID", groupId);
        startActivity(intent);
    }
}