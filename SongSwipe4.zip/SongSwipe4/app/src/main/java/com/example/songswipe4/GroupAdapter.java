package com.example.songswipe4;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.util.Pair;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.ArrayList;

public class GroupAdapter extends RecyclerView.Adapter<GroupAdapter.GroupViewHolder> {
    private List<Group> groups;
    private OnGroupClickListener listener;
    private int selectedPosition = RecyclerView.NO_POSITION;

    public interface OnGroupClickListener {
        void onGroupClick(Group group);
    }

    public GroupAdapter(List<Group> groups, OnGroupClickListener listener) {
        this.groups = groups;
        this.listener = listener;
    }

    @NonNull
    @Override
    public GroupViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_group, parent, false);
        return new GroupViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GroupViewHolder holder, int position) {
        Group group = groups.get(position);
        Log.d("GroupAdapter", "Binding group at position " + position +
                ", name: " + group.getName() +
                ", members: " + group.getMembers());

        holder.groupName.setTextColor(Color.WHITE);
        holder.groupName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        holder.groupName.setTypeface(null, Typeface.BOLD);
        holder.bind(group);
        holder.itemView.setSelected(selectedPosition == position);
    }

    @Override
    public int getItemCount() {
        return groups.size();
    }

    class GroupViewHolder extends RecyclerView.ViewHolder {
        private TextView groupName;
        private TextView groupMembers;
        private TextView memberCount;

        GroupViewHolder(@NonNull View itemView) {
            super(itemView);
            groupName = itemView.findViewById(R.id.group_name);
            groupMembers = itemView.findViewById(R.id.group_members);
            memberCount = itemView.findViewById(R.id.member_count);

            itemView.setOnClickListener(v -> {
                int previousPosition = selectedPosition;
                selectedPosition = getAdapterPosition();
                notifyItemChanged(previousPosition);
                notifyItemChanged(selectedPosition);
                if (selectedPosition != RecyclerView.NO_POSITION) {
                    listener.onGroupClick(groups.get(selectedPosition));
                }
            });
        }

        void bind(Group group) {
            Log.d("GroupAdapter", "Group name in bind: " + group.getName());
            groupName.setText("Group: " + group.getName());  // Add prefix to ensure text is being set
            groupName.setTextColor(Color.WHITE);  // Force white color
            groupName.setAllCaps(true);  // Make it stand out

            // Check if members list is null before using String.join
            List<String> members = group.getMembers();
            if (members == null || members.isEmpty()) {
                groupMembers.setText("No members");
                memberCount.setText("0 members");
            } else {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < members.size(); i++) {
                    sb.append(members.get(i));
                    if (i < members.size() - 1) {
                        sb.append(", ");
                    }
                }
                groupMembers.setText(sb.toString());
                memberCount.setText(String.format("%d members", members.size()));
            }
        }
    }
}