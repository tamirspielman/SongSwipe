package com.example.songswipe4;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.util.Pair;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import com.squareup.picasso.Callback;

import androidx.palette.graphics.Palette;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
//import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Settings extends Fragment {
    private Button logoutButton;
    private ImageView profileImageView;
    private ImageView userTypeIconView; // New ImageView for user type icon
    private TextView firstNameTextView, lastNameTextView, userEmailTextView;
    private TextView userTypeTextView; // New TextView to display user type
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firestore;
    private FirebaseUser currentUser;
    private String accessToken;
    private View rootView;
    private ImageButton notificationButton;

    private int dominantColor;
    private int buttonColor;
    private int textColor = Color.WHITE;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_settings, container, false);
        logoutButton = rootView.findViewById(R.id.logout_button);
        Button createGroupButton = rootView.findViewById(R.id.create_group_button);
        Button joinGroupButton = rootView.findViewById(R.id.join_group_button);
        profileImageView = rootView.findViewById(R.id.profile_image);
        firstNameTextView = rootView.findViewById(R.id.first_name);
        lastNameTextView = rootView.findViewById(R.id.last_name);
        userEmailTextView = rootView.findViewById(R.id.user_email);
        notificationButton = rootView.findViewById(R.id.notification_button);

        // Initialize new views for user type
        userTypeIconView = rootView.findViewById(R.id.user_type_icon);
        userTypeTextView = rootView.findViewById(R.id.user_type_text);

        firebaseAuth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
        currentUser = firebaseAuth.getCurrentUser();

        if (currentUser != null) {
            fetchUserProfile();
        }

        logoutButton.setOnClickListener(v -> {
            firebaseAuth.signOut();
            Intent intent = new Intent(requireContext(), LoginActivity.class);
            startActivity(intent);
            requireActivity().finish();
        });

        createGroupButton.setOnClickListener(v -> showCreateGroupDialog());
        joinGroupButton.setOnClickListener(v -> showJoinGroupDialog());

        notificationButton.setOnClickListener(v -> showNotifications());

        return rootView;
    }

    private void showNotifications() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Notifications");

        AlertDialog loadingDialog = builder.setMessage("Loading notifications...").create();
        loadingDialog.show();

        firestore.collection("notifications")
                .whereEqualTo("toUserId", currentUser.getUid())
                .get()
                .addOnCompleteListener(task -> {
                    loadingDialog.dismiss();

                    if (task.isSuccessful()) {
                        Map<String, DocumentSnapshot> uniqueNotifications = new LinkedHashMap<>();

                        for (DocumentSnapshot document : task.getResult()) {
                            String message = document.getString("message");
                            if (message != null) {
                                uniqueNotifications.put(message, document);
                            }
                        }

                        List<String> notifications = new ArrayList<>(uniqueNotifications.keySet());
                        List<DocumentSnapshot> documents = new ArrayList<>(uniqueNotifications.values());

                        AlertDialog.Builder resultBuilder = new AlertDialog.Builder(requireContext());
                        resultBuilder.setTitle("Notifications");

                        if (notifications.isEmpty()) {
                            resultBuilder.setMessage("You have no notifications");
                            resultBuilder.setPositiveButton("OK", (dialogInterface, which) -> dialogInterface.dismiss());
                            resultBuilder.create().show();
                        } else {
                            // Create the dialog before setting the items click listener
                            AlertDialog notificationsDialog = resultBuilder.create();

                            resultBuilder.setItems(notifications.toArray(new String[0]), (dialog, which) -> {
                                DocumentSnapshot selectedDoc = documents.get(which);

                                // Check if this is a join request notification
                                String type = selectedDoc.getString("type");
                                if (type != null && type.equals("join_request")) {
                                    // Pass the dialog interface to the handleJoinRequest method
                                    handleJoinRequest(selectedDoc, dialog);
                                } else {
                                    // Handle regular notification
                                    dismissNotification(selectedDoc, dialog, notifications, documents, which);
                                }
                            });

                            resultBuilder.setNegativeButton("Close", (dialog, which) -> dialog.dismiss());
                            resultBuilder.create().show();
                        }
                    }
                });
    }

    // Update the handleJoinRequest method to not require a dialog parameter
    private void handleJoinRequest(DocumentSnapshot notification, DialogInterface currentDialog) {
        String fromUserId = notification.getString("fromUserId");
        String groupId = notification.getString("groupId");
        String message = notification.getString("message");

        if (fromUserId == null || groupId == null) {
            Toast.makeText(requireContext(), "Invalid join request", Toast.LENGTH_SHORT).show();
            return;
        }

        // Close the current notifications dialog
        currentDialog.dismiss();

        // Create a confirmation dialog with custom layout
        AlertDialog.Builder confirmBuilder = new AlertDialog.Builder(requireContext());
        View confirmView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_join_request_confirmation, null);
        confirmBuilder.setView(confirmView);

        // Extract username and group name from the message
        // Typical message format: "Username requested to join your group: GroupName"
        String userName = "";
        String groupName = "";

        if (message != null) {
            int requestedIndex = message.indexOf("requested");
            int groupIndex = message.lastIndexOf("group:");

            if (requestedIndex > 0 && groupIndex > 0) {
                userName = message.substring(0, requestedIndex).trim();
                groupName = message.substring(groupIndex + 6).trim();
            }
        }

        // Set the user name and group name in the dialog
        TextView userNameText = confirmView.findViewById(R.id.user_name_text);
        TextView groupNameText = confirmView.findViewById(R.id.group_name_text);

        userNameText.setText(userName);
        groupNameText.setText(groupName);

        // Create the dialog
        AlertDialog dialog = confirmBuilder.create();

        // Set up button click listeners
        Button approveButton = confirmView.findViewById(R.id.approve_button);
        Button denyButton = confirmView.findViewById(R.id.deny_button);

        approveButton.setOnClickListener(v -> {
            // Approve the request
            approveJoinRequest(groupId, fromUserId, notification);
            dialog.dismiss();
        });

        denyButton.setOnClickListener(v -> {
            // Deny the request
            denyJoinRequest(groupId, fromUserId, notification);
            dialog.dismiss();
        });

        dialog.show();
    }
    private void handleJoinRequest(DocumentSnapshot notification, AlertDialog currentDialog) {
        String fromUserId = notification.getString("fromUserId");
        String groupId = notification.getString("groupId");
        String message = notification.getString("message");

        if (fromUserId == null || groupId == null) {
            Toast.makeText(requireContext(), "Invalid join request", Toast.LENGTH_SHORT).show();
            return;
        }

        // Close the current notifications dialog
        currentDialog.dismiss();

        // Create a confirmation dialog with custom layout
        AlertDialog.Builder confirmBuilder = new AlertDialog.Builder(requireContext());
        View confirmView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_join_request_confirmation, null);
        confirmBuilder.setView(confirmView);

        // Extract username and group name from the message
        // Typical message format: "Username requested to join your group: GroupName"
        String userName = "";
        String groupName = "";

        if (message != null) {
            int requestedIndex = message.indexOf("requested");
            int groupIndex = message.lastIndexOf("group:");

            if (requestedIndex > 0 && groupIndex > 0) {
                userName = message.substring(0, requestedIndex).trim();
                groupName = message.substring(groupIndex + 6).trim();
            }
        }

        // Set the user name and group name in the dialog
        TextView userNameText = confirmView.findViewById(R.id.user_name_text);
        TextView groupNameText = confirmView.findViewById(R.id.group_name_text);

        userNameText.setText(userName);
        groupNameText.setText(groupName);

        // Create the dialog
        AlertDialog dialog = confirmBuilder.create();

        // Set up button click listeners
        Button approveButton = confirmView.findViewById(R.id.approve_button);
        Button denyButton = confirmView.findViewById(R.id.deny_button);

        approveButton.setOnClickListener(v -> {
            // Approve the request
            approveJoinRequest(groupId, fromUserId, notification);
            dialog.dismiss();
        });

        denyButton.setOnClickListener(v -> {
            // Deny the request
            denyJoinRequest(groupId, fromUserId, notification);
            dialog.dismiss();
        });

        dialog.show();
    }


    private void approveJoinRequest(String groupId, String userId, DocumentSnapshot notification) {
        DocumentReference groupRef = firestore.collection("groups").document(groupId);

        firestore.runTransaction(transaction -> {
            DocumentSnapshot groupSnapshot = transaction.get(groupRef);

            if (!groupSnapshot.exists()) {
                try {
                    throw new Exception("Group does not exist");
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

            // Get group name for notification
            String groupName = groupSnapshot.getString("groupName");

            // Get current members and requests
            List<String> memberIds = (List<String>) groupSnapshot.get("memberIds");
            List<String> memberNames = (List<String>) groupSnapshot.get("members");
            Map<String, Object> requests = (Map<String, Object>) groupSnapshot.get("requests");

            if (memberIds == null) memberIds = new ArrayList<>();
            if (memberNames == null) memberNames = new ArrayList<>();
            if (requests == null) {
                try {
                    throw new Exception("No requests found in this group");
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

            // Get the user's request data
            Map<String, Object> requestData = (Map<String, Object>) requests.get(userId);
            if (requestData == null) {
                try {
                    throw new Exception("Request not found for this user");
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

            // Add user to members
            memberIds.add(userId);
            String userName = (String) requestData.get("userName");
            if (userName == null) {
                // Fallback if userName is not in request data
                userName = "New Member";
            }
            memberNames.add(userName);

            // Remove from requests
            requests.remove(userId);

            // Update the group document
            Map<String, Object> updates = new HashMap<>();
            updates.put("memberIds", memberIds);
            updates.put("members", memberNames);
            updates.put("requests", requests);

            transaction.update(groupRef, updates);

            // Return the group name for use in the success callback
            return groupName;
        }).addOnSuccessListener(groupName -> {
            // Send notification to the user that they've been approved
            Map<String, Object> approvalNotification = new HashMap<>();
            String notificationMessage = "Your request to join ";
            notificationMessage += (groupName != null) ?
                    "the group '" + groupName + "' has been approved!" :
                    "a group has been approved!";

            approvalNotification.put("message", notificationMessage);
            approvalNotification.put("toUserId", userId);
            approvalNotification.put("fromUserId", currentUser.getUid());
            approvalNotification.put("timestamp", System.currentTimeMillis());
            approvalNotification.put("type", "join_approved");
            approvalNotification.put("groupId", groupId);

            firestore.collection("notifications").add(approvalNotification)
                    .addOnSuccessListener(documentReference -> {
                        // Delete the original notification only after successfully adding the new one
                        notification.getReference().delete()
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(requireContext(), "User approved to join the group", Toast.LENGTH_SHORT).show();
                                })
                                .addOnFailureListener(e -> {
                                    Log.e("Settings", "Error deleting original notification", e);
                                    // Still show success message even if notification deletion fails
                                    Toast.makeText(requireContext(), "User approved, but couldn't clear notification", Toast.LENGTH_SHORT).show();
                                });
                    })
                    .addOnFailureListener(e -> {
                        Log.e("Settings", "Error sending approval notification", e);
                        Toast.makeText(requireContext(), "User approved, but couldn't send notification", Toast.LENGTH_SHORT).show();
                    });
        }).addOnFailureListener(e -> {
            Log.e("Settings", "Error approving join request", e);
            Toast.makeText(requireContext(), "Failed to approve request: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }

    private void denyJoinRequest(String groupId, String userId, DocumentSnapshot notification) {
        DocumentReference groupRef = firestore.collection("groups").document(groupId);

        firestore.runTransaction(transaction -> {
            DocumentSnapshot groupSnapshot = transaction.get(groupRef);

            if (!groupSnapshot.exists()) {
                try {
                    throw new Exception("Group does not exist");
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

            // Get group name for notification
            String groupName = groupSnapshot.getString("groupName");

            // Get current requests
            Map<String, Object> requests = (Map<String, Object>) groupSnapshot.get("requests");

            if (requests == null) {
                try {
                    throw new Exception("No requests found in this group");
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

            // Check if the request exists
            if (!requests.containsKey(userId)) {
                try {
                    throw new Exception("Request not found for this user");
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

            // Remove from requests
            requests.remove(userId);
            transaction.update(groupRef, "requests", requests);

            // Return the group name for use in the success callback
            return groupName;
        }).addOnSuccessListener(groupName -> {
            // Send notification to the user that they've been denied
            Map<String, Object> denialNotification = new HashMap<>();
            String notificationMessage = "Your request to join ";
            notificationMessage += (groupName != null) ?
                    "the group '" + groupName + "' has been denied." :
                    "a group has been denied.";

            denialNotification.put("message", notificationMessage);
            denialNotification.put("toUserId", userId);
            denialNotification.put("fromUserId", currentUser.getUid());
            denialNotification.put("timestamp", System.currentTimeMillis());
            denialNotification.put("type", "join_denied");
            denialNotification.put("groupId", groupId);

            firestore.collection("notifications").add(denialNotification)
                    .addOnSuccessListener(documentReference -> {
                        // Delete the original notification only after successfully adding the new one
                        notification.getReference().delete()
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(requireContext(), "Join request denied", Toast.LENGTH_SHORT).show();
                                })
                                .addOnFailureListener(e -> {
                                    Log.e("Settings", "Error deleting original notification", e);
                                    // Still show success message even if notification deletion fails
                                    Toast.makeText(requireContext(), "Request denied, but couldn't clear notification", Toast.LENGTH_SHORT).show();
                                });
                    })
                    .addOnFailureListener(e -> {
                        Log.e("Settings", "Error sending denial notification", e);
                        Toast.makeText(requireContext(), "Request denied, but couldn't send notification", Toast.LENGTH_SHORT).show();
                    });
        }).addOnFailureListener(e -> {
            Log.e("Settings", "Error denying join request", e);
            Toast.makeText(requireContext(), "Failed to deny request: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }


    private void dismissNotification(DocumentSnapshot selectedDoc, DialogInterface dialog,
                                     List<String> notifications, List<DocumentSnapshot> documents, int which) {
        // Delete from Firestore
        selectedDoc.getReference().delete()
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(requireContext(), "Notification dismissed", Toast.LENGTH_SHORT).show();

                    // Remove from local lists
                    notifications.remove(which);
                    documents.remove(which);

                    dialog.dismiss();

                    // Show updated dialog if there are remaining notifications
                    if (!notifications.isEmpty()) {
                        AlertDialog.Builder updatedBuilder = new AlertDialog.Builder(requireContext());
                        updatedBuilder.setTitle("Notifications");
                        updatedBuilder.setItems(notifications.toArray(new String[0]), null);
                        updatedBuilder.setNegativeButton("Close", (dialogInterface, id) -> dialogInterface.dismiss());
                        updatedBuilder.create().show();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(requireContext(), "Failed to dismiss notification", Toast.LENGTH_SHORT).show();
                });
    }
    private void showCreateGroupDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Create Group");

        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_create_group, null);
        builder.setView(dialogView);

        EditText searchUserEditText = dialogView.findViewById(R.id.search_user_edit_text);
        RecyclerView usersRecyclerView = dialogView.findViewById(R.id.users_recycler_view);

        usersRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        List<String> allUsers = new ArrayList<>();
        List<String> displayedUsers = new ArrayList<>();
        List<String> selectedUsers = new ArrayList<>();
        Map<String, String> userIdMap = new HashMap<>(); // Map to store user names to user IDs

        UserAdapter userAdapter = new UserAdapter(displayedUsers, selectedUsersList -> {
            selectedUsers.clear();
            selectedUsers.addAll(selectedUsersList);
        });
        usersRecyclerView.setAdapter(userAdapter);
        firestore.collection("users").get().addOnSuccessListener(queryDocumentSnapshots -> {
            allUsers.clear();
            displayedUsers.clear();
            userIdMap.clear();
            for (DocumentSnapshot document : queryDocumentSnapshots.getDocuments()) {
                if (!document.getId().equals(currentUser.getUid())) {
                    String userName = document.getString("firstName") + " " + document.getString("lastName");
                    allUsers.add(userName);
                    userIdMap.put(userName, document.getId()); // Store the mapping of name to user ID
                }
            }
            displayedUsers.addAll(allUsers);
            userAdapter.notifyDataSetChanged();
        });
        searchUserEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                displayedUsers.clear();
                for (String user : allUsers) {
                    if (user.toLowerCase().contains(s.toString().toLowerCase())) {
                        displayedUsers.add(user);
                    }
                }
                userAdapter.notifyDataSetChanged();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        builder.setPositiveButton("Create", (dialog, which) -> {
            if (!selectedUsers.isEmpty()) {
                createGroup(selectedUsers, userIdMap);
            } else {
                Toast.makeText(requireContext(), "Please select at least one user to create a group", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }

    private void createGroup(List<String> selectedUsers, Map<String, String> userIdMap) {
        // Show dialog for group name input
        AlertDialog.Builder nameBuilder = new AlertDialog.Builder(requireContext());
        nameBuilder.setTitle("Name Your Group");

        EditText groupNameInput = new EditText(requireContext());
        groupNameInput.setHint("Enter group name");
        nameBuilder.setView(groupNameInput);

        nameBuilder.setPositiveButton("Create", (dialog, which) -> {
            String groupName = groupNameInput.getText().toString().trim();
            if (!groupName.isEmpty()) {
                String groupId = firestore.collection("groups").document().getId();

                firestore.collection("users").document(currentUser.getUid()).get()
                        .addOnSuccessListener(documentSnapshot -> {
                            String creatorName = documentSnapshot.getString("firstName") + " " + documentSnapshot.getString("lastName");

                            // Create lists for member names and member IDs
                            List<String> memberNames = new ArrayList<>();
                            List<String> memberIds = new ArrayList<>();

                            // Add creator
                            memberNames.add(creatorName);
                            memberIds.add(currentUser.getUid());

                            // Add selected users and their IDs
                            for (String userName : selectedUsers) {
                                memberNames.add(userName);
                                String userId = userIdMap.get(userName);
                                if (userId != null) {
                                    memberIds.add(userId);
                                }
                            }

                            Map<String, Object> groupData = new HashMap<>();
                            groupData.put("members", memberNames);
                            groupData.put("memberIds", memberIds);
                            groupData.put("requests", new HashMap<>());
                            groupData.put("creatorId", currentUser.getUid());
                            groupData.put("groupName", groupName);
                            groupData.put("createdAt", System.currentTimeMillis());

                            firestore.collection("groups").document(groupId).set(groupData)
                                    .addOnSuccessListener(aVoid -> {
                                        // Send notifications to all members
                                        for (String userId : memberIds) {
                                            if (!userId.equals(currentUser.getUid())) {
                                                Map<String, Object> notification = new HashMap<>();
                                                notification.put("message", "You have been added to group: " + groupName);
                                                notification.put("toUserId", userId);
                                                notification.put("fromUserId", currentUser.getUid());
                                                notification.put("timestamp", System.currentTimeMillis());
                                                notification.put("type", "group_invitation");
                                                notification.put("groupId", groupId);

                                                firestore.collection("notifications").add(notification);
                                            }
                                        }

                                        Toast.makeText(requireContext(), "Group created successfully!", Toast.LENGTH_SHORT).show();
                                    })
                                    .addOnFailureListener(e -> {
                                        Log.e("Settings", "Error creating group", e);
                                        Toast.makeText(requireContext(), "Failed to create group", Toast.LENGTH_SHORT).show();
                                    });
                        });
            } else {
                Toast.makeText(requireContext(), "Please enter a group name", Toast.LENGTH_SHORT).show();
            }
        });

        nameBuilder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        nameBuilder.create().show();
    }

    private void joinGroup(String groupId) {
        String userId = currentUser.getUid();

        // Get user information first
        firestore.collection("users").document(userId).get()
                .addOnSuccessListener(userDoc -> {
                    if (userDoc.exists()) {
                        String userName = userDoc.getString("firstName") + " " + userDoc.getString("lastName");

                        // Now get the group information
                        DocumentReference groupRef = firestore.collection("groups").document(groupId);
                        groupRef.get().addOnSuccessListener(groupDoc -> {
                            if (groupDoc.exists()) {
                                // Get the group name for notification
                                String groupName = groupDoc.getString("groupName");
                                String creatorId = groupDoc.getString("creatorId");

                                // Update the requests map
                                Map<String, Object> requests = (Map<String, Object>) groupDoc.get("requests");
                                if (requests == null) requests = new HashMap<>();

                                // Store both user ID and name in the request
                                Map<String, Object> requestData = new HashMap<>();
                                requestData.put("userId", userId);
                                requestData.put("userName", userName);
                                requestData.put("approved", false);
                                requestData.put("timestamp", System.currentTimeMillis());

                                requests.put(userId, requestData);

                                groupRef.update("requests", requests)
                                        .addOnSuccessListener(aVoid -> {
                                            // Send notification to group creator
                                            if (creatorId != null) {
                                                Map<String, Object> notification = new HashMap<>();
                                                notification.put("message", userName + " requested to join your group: " + groupName);
                                                notification.put("toUserId", creatorId);
                                                notification.put("fromUserId", userId);
                                                notification.put("timestamp", System.currentTimeMillis());
                                                notification.put("type", "join_request");
                                                notification.put("groupId", groupId);

                                                firestore.collection("notifications").add(notification)
                                                        .addOnSuccessListener(notificationRef -> {
                                                            Toast.makeText(getContext(), "Join request sent!", Toast.LENGTH_SHORT).show();
                                                        })
                                                        .addOnFailureListener(e -> {
                                                            Log.e("Settings", "Error sending notification", e);
                                                        });
                                            } else {
                                                Toast.makeText(getContext(), "Join request sent!", Toast.LENGTH_SHORT).show();
                                            }
                                        })
                                        .addOnFailureListener(e -> {
                                            Log.e("Settings", "Error sending join request", e);
                                            Toast.makeText(getContext(), "Failed to send join request", Toast.LENGTH_SHORT).show();
                                        });
                            } else {
                                Toast.makeText(getContext(), "Group not found!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e("Settings", "Error fetching user data", e);
                    Toast.makeText(getContext(), "Failed to fetch user data", Toast.LENGTH_SHORT).show();
                });
    }
    private void showJoinGroupDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Join Group");

        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_join_group, null);
        builder.setView(dialogView);

        EditText searchGroupEditText = dialogView.findViewById(R.id.search_group_edit_text);
        RecyclerView groupsRecyclerView = dialogView.findViewById(R.id.groups_recycler_view);
        groupsRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        List<Group> allGroups = new ArrayList<>();
        List<Group> displayedGroups = new ArrayList<>();

        GroupAdapter groupAdapter = new GroupAdapter(displayedGroups, group -> {
            joinGroup(group.getId());
        });

        groupsRecyclerView.setAdapter(groupAdapter);

        String currentUserId = currentUser.getUid();
        firestore.collection("groups").get().addOnSuccessListener(queryDocumentSnapshots -> {
            allGroups.clear();
            displayedGroups.clear();
            for (DocumentSnapshot document : queryDocumentSnapshots.getDocuments()) {
                String creatorId = document.getString("creatorId");
                List<String> memberIds = (List<String>) document.get("memberIds");
                Map<String, Object> requests = (Map<String, Object>) document.get("requests");

                // Skip groups where user is already a member or has a pending request
                boolean isCreator = creatorId != null && creatorId.equals(currentUserId);
                boolean isMember = memberIds != null && memberIds.contains(currentUserId);
                boolean hasRequest = requests != null && requests.containsKey(currentUserId);

                if (!isCreator && !isMember && !hasRequest) {
                    Group group = new Group();
                    group.setId(document.getId());
                    group.setName(document.getString("groupName"));
                    if (creatorId != null) {
                        firestore.collection("users").document(creatorId).get()
                                .addOnSuccessListener(creatorDoc -> {
                                    if (creatorDoc.exists()) {
                                        String creatorName = creatorDoc.getString("firstName") + " " +
                                                creatorDoc.getString("lastName");
                                        group.setCreatorName(creatorName);
                                        groupAdapter.notifyDataSetChanged();
                                    }
                                });
                    }

                    allGroups.add(group);
                }
            }
            displayedGroups.addAll(allGroups);
            groupAdapter.notifyDataSetChanged();
        });

        searchGroupEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                displayedGroups.clear();
                String searchText = s.toString().toLowerCase();
                for (Group group : allGroups) {
                    if (group.getName().toLowerCase().contains(searchText)) {
                        displayedGroups.add(group);
                    }
                }
                groupAdapter.notifyDataSetChanged();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }

    private void fetchUserProfile() {
        firestore.collection("users").document(currentUser.getUid()).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String firstName = documentSnapshot.getString("firstName");
                        String lastName = documentSnapshot.getString("lastName");
                        String email = documentSnapshot.getString("email");
                        String spotifyToken = documentSnapshot.getString("spotifyToken");

                        firstNameTextView.setText(firstName);
                        lastNameTextView.setText(lastName);
                        userEmailTextView.setText(email);
                        accessToken = spotifyToken;

                        // Check user status
                        boolean isPremium = documentSnapshot.getBoolean("isPremium") != null &&
                                documentSnapshot.getBoolean("isPremium");
                        boolean isTopUser = documentSnapshot.getBoolean("isTopUser") != null &&
                                documentSnapshot.getBoolean("isTopUser");

                        // Create the appropriate user object based on status
                        User updatedUser;
                        if (isTopUser) {
                            updatedUser = new TopUser(currentUser.getUid(), email, firstName, lastName, spotifyToken);
                        } else if (isPremium) {
                            updatedUser = new PremiumUser(currentUser.getUid(), email, firstName, lastName, spotifyToken);
                        } else {
                            updatedUser = new User(currentUser.getUid(), email, firstName, lastName, spotifyToken);
                        }

                        // Set premium status (might be needed for other functionality)
                        updatedUser.setPremium(isPremium);

                        // Display user type info using polymorphic method
                        setUserTypeDisplay(updatedUser);

                        Button createGroupButton = rootView.findViewById(R.id.create_group_button);
                        Button joinGroupButton = rootView.findViewById(R.id.join_group_button);

                        // Use the polymorphic canCreateOrJoinGroup() method
                        boolean canAccessGroups = updatedUser.canCreateOrJoinGroup();
                        createGroupButton.setVisibility(canAccessGroups ? View.VISIBLE : View.GONE);
                        joinGroupButton.setVisibility(canAccessGroups ? View.VISIBLE : View.GONE);

                        fetchSpotifyProfileImage();
                    }
                });
    }



    private void setUserTypeDisplay(User user) {
        userTypeTextView.setText(user.getUserDetails());
        userTypeIconView.setImageResource(user.getUserBadge());
    }

    private void fetchSpotifyProfileImage() {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url("https://api.spotify.com/v1/me")
                .addHeader("Authorization", "Bearer " + accessToken)
                .build();

        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                requireActivity().runOnUiThread(() -> {
                    Log.e("SpotifyAPI", "Error fetching profile image", e);
                    Toast.makeText(requireContext(), "Failed to fetch profile image", Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String responseData = response.body().string();
                if (response.isSuccessful()) {
                    requireActivity().runOnUiThread(() -> {
                        try {
                            JSONObject jsonObject = new JSONObject(responseData);
                            String profileImageUrl = jsonObject.getJSONArray("images")
                                    .length() > 0 ? jsonObject.getJSONArray("images").getJSONObject(0).getString("url") : null;

                            if (profileImageUrl != null) {
                                Picasso.get().load(profileImageUrl).into(new Target() {
                                    @Override
                                    public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                                        profileImageView.setImageBitmap(bitmap);
                                        extractColorsFromImage(bitmap); // Extract dominant color after image is loaded
                                    }

                                    @Override
                                    public void onBitmapFailed(Exception e, Drawable errorDrawable) {
                                        Log.e("Picasso", "Error loading image", e);
                                    }

                                    @Override
                                    public void onPrepareLoad(Drawable placeHolderDrawable) {}
                                });
                            } else {
                                Toast.makeText(requireContext(), "No profile image found", Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {
                            Log.e("SpotifyAPI", "Error parsing profile image JSON", e);
                        }
                    });
                } else {
                    requireActivity().runOnUiThread(() -> {
                        Log.e("SpotifyAPI", "Failed with code: " + response.code());
                    });
                    if(response.code()==401) profileImageView.setImageResource(R.drawable.default_profile);
                }
            }
        });
    }

    private void extractColorsFromImage(Bitmap bitmap) {
        Palette.from(bitmap).generate(palette -> {
            if (palette != null) {
                dominantColor = palette.getDominantColor(Color.BLACK);  // Get dominant color
                buttonColor = palette.getVibrantColor(Color.BLACK);  // Get vibrant color for buttons
                applyColors();
            }
        });
    }
    private void applyColors() {
        rootView.setBackgroundColor(dominantColor);
        firstNameTextView.setTextColor(textColor);
        lastNameTextView.setTextColor(textColor);
        userEmailTextView.setTextColor(textColor);
        if (userTypeTextView != null) {
            userTypeTextView.setTextColor(textColor);
        }
    }
}