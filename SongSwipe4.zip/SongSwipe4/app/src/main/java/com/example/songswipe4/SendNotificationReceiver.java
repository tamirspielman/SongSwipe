package com.example.songswipe4;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;

import java.util.Objects;

public class SendNotificationReceiver extends BroadcastReceiver {

    private NotificationManager manager;
    private NotificationChannel channel;
    private static final String NOTIFICATION_CHANNEL_ID = "SONG_VIBE_CHANNEL";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();

        if (Objects.equals(action, "com.example.songswipe4.INVITE_NOTIFICATION")) {
            // Handle game invitations
            String message = intent.getStringExtra("message");
            String userId = intent.getStringExtra("userId");
            Log.d("SendNotificationReceiver", "Game invitation for user: " + userId);

            makeNotification("Game Invitation", message, context, null);

        } else {
            // Handle existing daily playlist notifications
            String accessToken = intent.getStringExtra("ACCESS_TOKEN");
            Toast.makeText(context, "Notification Triggered", Toast.LENGTH_LONG).show();
            Log.d("SendNotificationReceiver", "Building notification");
            makeNotification("Your Daily Playlist Reminder", "Check out your playlist!", context, accessToken);
        }
    }
    private void makeNotification(String notiTitle, String notiText, Context context, String accessToken) {
        // Initialize the notification manager
        manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Create notification channel for Android O and above
            channel = new NotificationChannel(
                    NOTIFICATION_CHANNEL_ID,
                    context.getString(R.string.app_name),
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Channel for game invitations and daily playlist notifications");
            channel.setLightColor(Color.GREEN);

            if (manager != null) {
                manager.createNotificationChannel(channel);
            }

            // Create an Intent for the notification
            Intent intent = new Intent(context, menu_holder.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            if (accessToken != null) intent.putExtra("ACCESS_TOKEN", accessToken);

            PendingIntent pendingIntent = PendingIntent.getActivity(
                    context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            Notification.Builder notificationBuilder = new Notification.Builder(context, NOTIFICATION_CHANNEL_ID)
                    .setContentTitle(notiTitle)
                    .setContentText(notiText)
                    .setSmallIcon(R.drawable.rec)  // Replace with your small icon
                    .setAutoCancel(true) // Remove the notification when tapped
                    .setContentIntent(pendingIntent);

            if (manager != null) {
                manager.notify((int) System.currentTimeMillis(), notificationBuilder.build());
            }
        } else {
            // For versions lower than Android O
            Intent intent = new Intent(context, menu_holder.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            if (accessToken != null) intent.putExtra("ACCESS_TOKEN", accessToken);

            PendingIntent pendingIntent = PendingIntent.getActivity(
                    context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            Notification.Builder notificationBuilder = new Notification.Builder(context)
                    .setContentTitle(notiTitle)
                    .setContentText(notiText)
                    .setSmallIcon(R.drawable.rec)
                    .setPriority(Notification.PRIORITY_HIGH)
                    .setAutoCancel(true)
                    .setContentIntent(pendingIntent);

            if (manager != null) {
                manager.notify((int) System.currentTimeMillis(), notificationBuilder.build());
            }
        }
    }
}