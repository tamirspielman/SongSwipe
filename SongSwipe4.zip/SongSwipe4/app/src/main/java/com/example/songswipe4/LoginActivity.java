package com.example.songswipe4;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Calendar;

public class LoginActivity extends AppCompatActivity {

    private EditText emailField, passwordField;
    private Button loginButton, signUpButton;
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firestore;
    private static final String TAG = "LoginActivity";
    private static final String CLIENT_ID = "a9cd759ea4c44376b10a39aa4b1cdabd";  // Replace with your Spotify client ID
    private static final String REDIRECT_URI = "songswipe://callback";  // Replace with your redirect URI
    private static final String AUTH_URL = "https://accounts.spotify.com/authorize";
    private static final String RESPONSE_TYPE = "token";
    private static final String SCOPES = "user-library-read playlist-modify-public playlist-modify-private";
    private static final String NOTIFICATION_CHANNEL_ID = "SONG_VIBE_CHANNEL";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        firestore = FirebaseFirestore.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = firebaseAuth.getCurrentUser();

        Log.d(TAG, "FirebaseUser: " + (currentUser != null ? currentUser.getUid() : "null"));
        createNotificationChannel();
        if (currentUser != null) {
            fetchAccessTokenFromFirestore(currentUser.getUid());
        } else {
            initializeLoginUI();
        }

        handleSpotifyRedirect(getIntent());
    }
    private void fetchAccessTokenFromFirestore(String userId) {
        firestore.collection("users").document(userId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String accessToken = documentSnapshot.getString("spotifyToken");
                        Log.d(TAG, "Fetched AccessToken from Firestore: " + accessToken);

                        if (accessToken != null && !accessToken.isEmpty()) {
                            proceedToNextActivity(accessToken);
                        } else {
                            Log.e(TAG, "AccessToken is null or empty in Firestore.");
                            initializeLoginUI();
                        }
                    } else {
                        Log.e(TAG, "User document does not exist in Firestore.");
                        initializeLoginUI();
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Failed to fetch AccessToken from Firestore.", e);
                    initializeLoginUI();
                });
    }

    private void initializeLoginUI() {
        emailField = findViewById(R.id.email_field);
        passwordField = findViewById(R.id.password_field);
        loginButton = findViewById(R.id.login_button);
        signUpButton = findViewById(R.id.sign_up_button);

        loginButton.setOnClickListener(v -> {
            Log.d(TAG, "Login button clicked.");
            loginUser();
        });

        signUpButton.setOnClickListener(v -> {
            Log.d(TAG, "Sign-up button clicked.");
            startActivity(new Intent(this, SignUpActivity.class));
        });
    }

    private void loginUser() {
        String email = emailField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "Fields are empty.");
            return;
        }

        Log.d(TAG, "Attempting login with email: " + email);

        firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        Log.d(TAG, "Login successful. Redirecting to Spotify login.");
                        redirectToSpotifyLogin();
                    } else {
                        Log.e(TAG, "Login failed.", task.getException());
                        Toast.makeText(this, "Login failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void redirectToSpotifyLogin() {
        String loginUrl = AUTH_URL +
                "?client_id=" + CLIENT_ID +
                "&response_type=" + RESPONSE_TYPE +
                "&redirect_uri=" + Uri.encode(REDIRECT_URI) +
                "&scope=" + Uri.encode(SCOPES);
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(loginUrl));
        startActivity(browserIntent);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.d(TAG, "onNewIntent called with data: " + intent.getData());
        handleSpotifyRedirect(intent);
    }
    private void handleSpotifyRedirect(Intent intent) {
        Uri uri = intent.getData();
        if (uri != null) {
            Log.d(TAG, "Redirect URI: " + uri);
            if (uri.toString().startsWith(REDIRECT_URI)) {
                String fragment = uri.getFragment();
                if (fragment != null) {
                    String accessToken = getAccessTokenFromFragment(fragment);
                    if (accessToken != null && !accessToken.isEmpty()) {
                        Log.d(TAG, "Extracted Token: " + accessToken);

                        // Store the access token in Firestore
                        FirebaseUser currentUser = firebaseAuth.getCurrentUser();
                        if (currentUser != null) {
                            updateAccessTokenInFirestore(currentUser.getUid(), accessToken);
                        }

                        // Proceed to the next activity with the access token
                        proceedToNextActivity(accessToken);
                    } else {
                        Log.e(TAG, "Access token extraction failed.");
                        Toast.makeText(this, "Spotify authorization failed.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        } else {
            Log.d(TAG, "No data in redirect intent.");
        }
    }
    private void updateAccessTokenInFirestore(String userId, String accessToken) {
        firestore.collection("users").document(userId)
                .update("spotifyToken", accessToken)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Access token successfully updated in Firestore.");
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Failed to update access token in Firestore.", e);
                });
    }

    private String getAccessTokenFromFragment(String fragment) {
        String[] params = fragment.split("&");
        for (String param : params) {
            if (param.startsWith("access_token=")) {
                return Uri.decode(param.substring("access_token=".length()));
            }
        }
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    NOTIFICATION_CHANNEL_ID,
                    "Daily Song Vibe",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Daily reminder to check your song vibe.");
            channel.enableLights(true);
            channel.setLightColor(Color.BLUE);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private void scheduleDailyNotification() {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, SendNotificationReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Set the time for 8 PM
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 20);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);

        // Schedule the alarm to repeat daily at 8 PM
        if (alarmManager != null) {
            alarmManager.setRepeating(
                    AlarmManager.RTC_WAKEUP,
                    calendar.getTimeInMillis(),
                    AlarmManager.INTERVAL_DAY,
                    pendingIntent
            );
        }
    }

    private void proceedToNextActivity(String accessToken) {
        Intent nextActivity = new Intent(this, menu_holder.class);
        nextActivity.putExtra("ACCESS_TOKEN", accessToken);
        startActivity(nextActivity);
        finish();
    }
}
