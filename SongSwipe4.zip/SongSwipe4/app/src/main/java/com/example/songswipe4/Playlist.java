package com.example.songswipe4;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Playlist extends Fragment {
    private Button clearPlaylistButton;
    private Button addToSpotifyButton;
    private RecyclerView playlistRecyclerView;
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firestore;
    private String accessToken;
    private View rootView;
    private FirestoreRecyclerAdapter<Song, SongViewHolder> adapter;

    public static class SongViewHolder extends RecyclerView.ViewHolder {
        TextView songTitleView;

        public SongViewHolder(View itemView) {
            super(itemView);
            songTitleView = itemView.findViewById(android.R.id.text1);
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        firebaseAuth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_playlist, container, false);
        playlistRecyclerView = rootView.findViewById(R.id.playlist_list);
        playlistRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        clearPlaylistButton = rootView.findViewById(R.id.clear_playlist_button);
        addToSpotifyButton = rootView.findViewById(R.id.add_to_spotify_button);

        loadAccessTokenFromFirestore();
        setupFirebaseAdapter();
        playlistRecyclerView.setAdapter(adapter);
        setupButtonListeners();

        return rootView;
    }

    private void setupFirebaseAdapter() {
        String userId = firebaseAuth.getCurrentUser().getUid();
        Query query = firestore.collection("Song").whereEqualTo("userId", userId);

        FirestoreRecyclerOptions<Song> options = new FirestoreRecyclerOptions.Builder<Song>()
                .setQuery(query, Song.class)
                .setLifecycleOwner(this)
                .build();

        adapter = new FirestoreRecyclerAdapter<Song, SongViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull SongViewHolder holder, int position, @NonNull Song song) {
                try {
                    holder.songTitleView.setText(song.getTitle() + " - " + song.getArtist());

                    holder.itemView.setOnClickListener(v -> {
                        Intent intent = new Intent(requireContext(), SongDetailsActivity.class);
                        intent.putExtra("image_url", song.getAlbumCoverUrl());
                        intent.putExtra("song_name", song.getTitle());
                        intent.putExtra("song_artist", song.getArtist());
                        startActivity(intent);
                    });
                } catch (Exception e) {
                    Log.e("Playlist", "Error binding view holder", e);
                }
            }

            @NonNull
            @Override
            public SongViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext())
                        .inflate(android.R.layout.simple_list_item_1, parent, false);
                return new SongViewHolder(view);
            }
        };
    }

    private void clearPlaylist() {
        String userId = firebaseAuth.getCurrentUser().getUid();
        firestore.collection("Song")
                .whereEqualTo("userId", userId)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    for (DocumentSnapshot document : queryDocumentSnapshots) {
                        document.getReference().delete();
                    }
                    
                    Toast.makeText(requireContext(), "Playlist cleared successfully", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(requireContext(), "Failed to clear playlist", Toast.LENGTH_SHORT).show();
                });
    }

    private void createSpotifyPlaylist() {
        String createPlaylistUrl = "https://api.spotify.com/v1/me/playlists";
        JSONObject playlistData = new JSONObject();
        try {
            playlistData.put("name", "My SongSwipe Playlist");
            playlistData.put("description", "Created by SongSwipe App");
            playlistData.put("public", false);
        } catch (JSONException e) {
            Log.e("SpotifyDebug", "JSON creation error", e);
            return;
        }

        RequestBody body = RequestBody.create(
                MediaType.get("application/json"),
                playlistData.toString()
        );

        Request request = new Request.Builder()
                .url(createPlaylistUrl)
                .post(body)
                .addHeader("Authorization", "Bearer " + accessToken)
                .addHeader("Content-Type", "application/json")
                .build();

        Toast.makeText(requireContext(), "Creating Spotify playlist...", Toast.LENGTH_SHORT).show();

        new OkHttpClient().newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                requireActivity().runOnUiThread(() -> Toast.makeText(requireContext(),
                        "Failed to create playlist: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    String jsonData = response.body().string();
                    try {
                        JSONObject json = new JSONObject(jsonData);
                        String playlistId = json.getString("id");
                        searchAndAddSongs(playlistId);
                        requireActivity().runOnUiThread(() -> Toast.makeText(requireContext(),
                                "Playlist created, adding songs...", Toast.LENGTH_SHORT).show());
                    } catch (JSONException e) {
                        requireActivity().runOnUiThread(() -> Toast.makeText(requireContext(),
                                "Error creating playlist", Toast.LENGTH_SHORT).show());
                    }
                }
            }
        });
    }
    private void searchAndAddSongs(String playlistId) {
        List<Song> songs = new ArrayList<>();
        for (int i = 0; i < adapter.getItemCount(); i++) {
            Song song = adapter.getItem(i);
            if (song != null) {
                songs.add(song);
            }
        }

        for (Song song : songs) {
            String query = song.getTitle() + " " + song.getArtist();
            String encodedQuery = Uri.encode(query);
            String searchUrl = "https://api.spotify.com/v1/search?q=" + encodedQuery + "&type=track&limit=1";

            Request searchRequest = new Request.Builder()
                    .url(searchUrl)
                    .addHeader("Authorization", "Bearer " + accessToken)
                    .build();

            new OkHttpClient().newCall(searchRequest).enqueue(new Callback() {
                @Override
                public void onFailure(@NonNull Call call, @NonNull IOException e) {
                    requireActivity().runOnUiThread(() ->
                            Toast.makeText(requireContext(), "Failed to search for song: " + song.getTitle(), Toast.LENGTH_SHORT).show()
                    );
                }

                @Override
                public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                    if (response.isSuccessful() && response.body() != null) {
                        String jsonData = response.body().string();
                        try {
                            JSONObject json = new JSONObject(jsonData);
                            JSONArray items = json.getJSONObject("tracks").getJSONArray("items");
                            if (items.length() > 0) {
                                String trackUri = items.getJSONObject(0).getString("uri");
                                addTrackToPlaylist(playlistId, trackUri);
                            }
                        } catch (JSONException e) {
                            requireActivity().runOnUiThread(() ->
                                    Toast.makeText(requireContext(), "Error parsing search results", Toast.LENGTH_SHORT).show()
                            );
                        }
                    }
                }
            });
        }
    }


    private void addTrackToPlaylist(String playlistId, String trackUri) {
        String addTrackUrl = "https://api.spotify.com/v1/playlists/" + playlistId + "/tracks";
        JSONObject trackData = new JSONObject();
        try {
            JSONArray uris = new JSONArray();
            uris.put(trackUri);
            trackData.put("uris", uris);
        } catch (JSONException e) {
            e.printStackTrace();
            return;
        }

        RequestBody body = RequestBody.create(
                MediaType.get("application/json"),
                trackData.toString()
        );

        Request request = new Request.Builder()
                .url(addTrackUrl)
                .post(body)
                .addHeader("Authorization", "Bearer " + accessToken)
                .addHeader("Content-Type", "application/json")
                .build();

        new OkHttpClient().newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                requireActivity().runOnUiThread(() -> Toast.makeText(requireContext(),
                        "Failed to add track to playlist", Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    requireActivity().runOnUiThread(() -> Toast.makeText(requireContext(),
                            "Track added successfully", Toast.LENGTH_SHORT).show());
                }
            }
        });
    }

    private void loadAccessTokenFromFirestore() {
        String userId = firebaseAuth.getCurrentUser().getUid();
        firestore.collection("users")
                .document(userId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        accessToken = documentSnapshot.getString("spotifyToken");
                        if (accessToken == null || accessToken.isEmpty()) {
                            Toast.makeText(requireContext(), "Access Token not available", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(requireContext(), "User data not found", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(requireContext(), "Error loading access token", Toast.LENGTH_SHORT).show());
    }

    private void setupButtonListeners() {
        clearPlaylistButton.setOnClickListener(v -> clearPlaylist());
        addToSpotifyButton.setOnClickListener(v -> {
            if (accessToken == null || accessToken.isEmpty()) {
                Intent intent = new Intent(requireContext(), LoginActivity.class);
                startActivity(intent);
                return;
            }
            if (adapter.getItemCount() == 0) {
                return;
            }
            createSpotifyPlaylist();
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }
    @Override
    public void onResume() {
        super.onResume();
        if (adapter != null) {
            adapter.notifyDataSetChanged();
            playlistRecyclerView.getRecycledViewPool().clear();
            playlistRecyclerView.setAdapter(null);
            playlistRecyclerView.setAdapter(adapter);
        }
    }
}
