package com.example.songswipe4;

import android.graphics.Color;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import android.util.Pair;

public class MembersAdapter extends RecyclerView.Adapter<MembersAdapter.MemberViewHolder> {
    // Class to hold member data including user type and userId
    public static class MemberData {
        public String name;
        public int score;
        public String userType;
        public String userId;
        public User user; // Reference to the User object

        public MemberData(String name, int score, String userType, User user) {
            this.name = name;
            this.score = score;
            this.userType = userType != null ? userType : "Bronze";
            this.userId = "";
            this.user = user;
        }

        public MemberData(String name, int score, String userType, String userId, User user) {
            this.name = name;
            this.score = score;
            this.userType = userType != null ? userType : "Bronze";
            this.userId = userId != null ? userId : "";
            this.user = user;
        }


        // For backward compatibility
        public MemberData(String name, int score, String userType, String userId) {
            this(name, score, userType, userId, null);
        }
    }

    private List<MemberData> members;

    public MembersAdapter(List<MemberData> members) {
        this.members = members;
    }

    @NonNull
    @Override
    public MemberViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_member, parent, false);
        return new MemberViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MemberViewHolder holder, int position) {
        MemberData member = members.get(position);
        Log.d("MembersAdapter", "Binding member: " + member.name +
                " with score: " + member.score +
                ", type: " + member.userType +
                ", userId: " + member.userId);

        holder.nameText.setText(member.name);
        holder.nameText.setTextColor(Color.WHITE);
        holder.nameText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);

        holder.scoreText.setText(String.valueOf(member.score));
        holder.scoreText.setTextColor(Color.WHITE);
        holder.scoreText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);

        // Use polymorphism to get the appropriate badge if user object is available
        if (member.user != null) {
            holder.userTypeIcon.setImageResource(member.user.getUserBadge());
        } else {
            // Fallback to the original switch statement if user object is not available
            switch (member.userType) {
                case "Gold":
                    holder.userTypeIcon.setImageResource(R.drawable.ic_gold_user);
                    break;
                case "Silver":
                    holder.userTypeIcon.setImageResource(R.drawable.ic_iron_user);
                    break;
                case "Bronze":
                default:
                    holder.userTypeIcon.setImageResource(R.drawable.ic_bronze_user);
                    break;
            }
        }

        // Highlight the top user (position 0)
        if (position == 0 && !members.isEmpty() && member.score > 0) {
            // Add visual indication for top user (e.g., background tint, larger text)
            holder.itemView.setBackgroundColor(Color.parseColor("#33FFFFFF")); // Semi-transparent white
            holder.nameText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18); // Slightly larger text
        } else {
            // Reset background for other users
            holder.itemView.setBackgroundColor(Color.TRANSPARENT);
        }

        // Make the icon visible
        holder.userTypeIcon.setVisibility(View.VISIBLE);
    }

    @Override
    public int getItemCount() {
        return members.size();
    }

    static class MemberViewHolder extends RecyclerView.ViewHolder {
        TextView nameText;
        TextView scoreText;
        ImageView userTypeIcon;

        MemberViewHolder(View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.member_name);
            scoreText = itemView.findViewById(R.id.member_score);
            userTypeIcon = itemView.findViewById(R.id.user_type_icon);
        }
    }
}
