package com.example.songswipe4;
public class User {
    private String uid;
    private String email;
    private String firstName;
    private String lastName;
    private String spotifyToken;
    private boolean isPremium;

    public User(String uid, String email, String firstName, String lastName, String spotifyToken) {
        this.uid = uid;
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.spotifyToken = spotifyToken;
        this.isPremium = false;
    }

    public String getUid() { return uid; }
    public void setUid(String uid) { this.uid = uid; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    public String getSpotifyToken() { return spotifyToken; }
    public void setSpotifyToken(String spotifyToken) { this.spotifyToken = spotifyToken; }
    public boolean isPremium() { return isPremium; }
    public void setPremium(boolean premium) { isPremium = premium; }

    public boolean canCreateOrJoinGroup() {
        return false; // Base users cannot create/join groups
    }
    public String getUserDetails(){
        return "Bronze";
    }
    public int getUserBadge(){
        return R.drawable.ic_bronze_user;
    }
}