package com.example.songswipe4;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

import FireBaseHandler.FireBaseHandler;

public class SignUpActivity extends AppCompatActivity {

    private EditText firstNameField, lastNameField, emailField, passwordField;
    private Button signUpButton;
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firestore;
    private static final String TAG = "SignUpActivity";
    private static final String CLIENT_ID = "a9cd759ea4c44376b10a39aa4b1cdabd";
    //private static final String CLIENT_SECRET_ID = "5c27faddd6584b11ba857401d1ed96fc";
    private static final String REDIRECT_URI = "songswipe://callback";
    private static final String AUTH_URL = "https://accounts.spotify.com/authorize";
    private static final String RESPONSE_TYPE = "token";
    private static final String SCOPES = "user-read-private playlist-modify-public user-library-read streaming";
    private FireBaseHandler fireBaseHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        firstNameField = findViewById(R.id.first_name);
        lastNameField = findViewById(R.id.last_name);
        emailField = findViewById(R.id.email);
        passwordField = findViewById(R.id.password);
        signUpButton = findViewById(R.id.sign_up_button);
        firebaseAuth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
        fireBaseHandler = new FireBaseHandler();
        signUpButton.setOnClickListener(v -> registerUser());
        Button loginLink = findViewById(R.id.login_link);
        loginLink.setOnClickListener(v -> {
            Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void registerUser() {
        String email = emailField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(SignUpActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }
        firebaseAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = firebaseAuth.getCurrentUser();
                        if (user != null) {
                            redirectToSpotifyLogin();
                            fireBaseHandler.storeUserInFirestore(user, firstNameField.getText().toString().trim(), lastNameField.getText().toString().trim());
                        }
                    } else {
                        Log.w(TAG, "createUserWithEmail:failure", task.getException());
                        Toast.makeText(SignUpActivity.this, "Sign-up failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
    private void redirectToSpotifyLogin() {
        String loginUrl = AUTH_URL +
                "?client_id=" + CLIENT_ID +
                "&response_type=" + RESPONSE_TYPE +
                "&redirect_uri=" + Uri.encode(REDIRECT_URI) +
                "&scope=" + Uri.encode(SCOPES);
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(loginUrl));
        startActivity(browserIntent);
    }
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleSpotifyRedirect(intent);
    }
    private void handleSpotifyRedirect(Intent intent) {
        Uri uri = intent.getData();
        if (uri != null) {
            Log.d(TAG, "Redirect URI: " + uri.toString());
            if (uri.toString().startsWith(REDIRECT_URI)) {
                String fragment = uri.getFragment();
                Log.d(TAG, "Fragment: " + fragment);
                if (fragment != null) {
                    String accessToken = getAccessTokenFromFragment(fragment);
                    Log.d(TAG, "Extracted Token: " + accessToken);
                    if (accessToken != null && !accessToken.isEmpty()) {
                        proceedToNextActivity(accessToken);
                        fireBaseHandler.updateSpotifyTokenInFirestore(accessToken);
                    } else {
                        Log.e(TAG, "Access token extraction failed.");
                        Toast.makeText(this, "Spotify authorization failed.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        } else {
            Log.d(TAG, "No data in redirect intent.");
        }
    }

    private String getAccessTokenFromFragment(String fragment) {
        String[] params = fragment.split("&");
        for (String param : params) {
            if (param.startsWith("access_token=")) {
                return Uri.decode(param.substring("access_token=".length()));
            }
        }
        return null;
    }
    private void proceedToNextActivity(String accessToken) {
        SharedPreferences sharedPreferences = getSharedPreferences("SongSwipePrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("ACCESS_TOKEN", accessToken);
        editor.apply();
        Intent nextActivity = new Intent(this, menu_holder.class);
        nextActivity.putExtra("ACCESS_TOKEN", accessToken);
        startActivity(nextActivity);
    }
}
