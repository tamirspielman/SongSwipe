package com.example.songswipe4;

import android.os.Bundle;
import android.view.MenuItem;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class menu_holder extends AppCompatActivity {
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_menu_holder);

        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(this::onNavigationItemSelected);
        boolean toPlaylist = getIntent().getBooleanExtra("toPlaylist",false);
        if(toPlaylist)loadFragment(new Playlist());
        if (savedInstanceState == null) {
            loadFragment(new SongRecommend());
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.menu_holder), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private boolean onNavigationItemSelected(MenuItem item) {
        Fragment fragment = null;
        int itemId = item.getItemId();

        if (itemId == R.id.action_song_recommendation) {
            fragment = new SongRecommend();
        } else if (itemId == R.id.action_playlist) {
            fragment = new Playlist();
        } else if (itemId == R.id.action_group_listening) {
            fragment = new GroupListening();
        } else if (itemId == R.id.action_settings) {
            fragment = new Settings();
        }

        if (fragment != null) {
            loadFragment(fragment);
            return true;
        }
        return false;
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }
}
