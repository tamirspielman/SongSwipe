package com.example.songswipe4;
public class Vote {
    private String userId;
    private boolean liked;

    public Vote() {}

    public Vote(String userId, boolean liked) {
        this.userId = userId;
        this.liked = liked;
    }

    public String getUserId() {
        return userId;
    }

    public boolean isLiked() {
        return liked;
    }
}