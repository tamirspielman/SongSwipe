package com.example.songswipe4;
public class TopUser extends PremiumUser {
    private static final double SCORE_MULTIPLIER = 2.0; // Double the points
    private int participationCount;
    private int totalScore;

    public TopUser(String uid, String email, String firstName, String lastName, String spotifyToken) {
        super(uid, email, firstName, lastName, spotifyToken);
        this.participationCount = 0;
        this.totalScore = 0;
    }
    @Override
    public String getUserDetails(){
        return "Gold";
    }
    @Override
    public int getUserBadge(){
        return R.drawable.ic_gold_user;
    }
    public int calculateScore(int baseScore) {
        return (int) (baseScore * SCORE_MULTIPLIER);
    }

    public void incrementParticipation() {
        this.participationCount++;
    }

    public void addScore(int points) {
        this.totalScore += calculateScore(points);
    }

    public int getParticipationCount() {
        return participationCount;
    }

    public int getTotalScore() {
        return totalScore;
    }
}